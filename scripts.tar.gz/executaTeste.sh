mv /var/log/snort/alert.fast /var/log/snort/alert.fast.cp
./mataProcessos.sh
sudo mn --custom /home/mininet/mininet/custom/cenarioTesteLAN-WAN.py
