sudo killall -9 controller iperf idswakeup snort tcpdump nmap apache2
