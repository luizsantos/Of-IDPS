cat createTablesPorts.sql | sqlite3 teste.db
cat createTablesFlows.sql | sqlite3 teste.db
