#!/bin/bash

snort -c /etc/snort/snort.conf &

