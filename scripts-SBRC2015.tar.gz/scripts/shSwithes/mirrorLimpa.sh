ovs-vsctl clear bridge s1 mirrors
