#!/bin/bash
ipGw="192.168.0.4"
route add default gw $ipGw
