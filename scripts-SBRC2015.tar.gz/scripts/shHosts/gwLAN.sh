#!/bin/bash
ipGw="10.0.0.4"
route add default gw $ipGw
