package net.beaconcontroller.tutorial;

import java.io.BufferedWriter;
import java.sql.*;
import org.sqlite.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import net.beaconcontroller.DAO.StatusPorta;
import net.beaconcontroller.DAO.StatusPortaDAO;
import net.beaconcontroller.core.IBeaconProvider;
import net.beaconcontroller.core.IOFMessageListener;
import net.beaconcontroller.core.IOFSwitch;
import net.beaconcontroller.packet.IPv4;

import org.openflow.protocol.OFMatch;
import org.openflow.protocol.OFMessage;
import org.openflow.protocol.OFPort;
import org.openflow.protocol.OFStatisticsReply;
import org.openflow.protocol.OFStatisticsRequest;
import org.openflow.protocol.OFType;
import org.openflow.protocol.statistics.OFFlowStatisticsReply;
import org.openflow.protocol.statistics.OFFlowStatisticsRequest;
import org.openflow.protocol.statistics.OFPortStatisticsReply;
import org.openflow.protocol.statistics.OFPortStatisticsRequest;
import org.openflow.protocol.statistics.OFStatistics;
import org.openflow.protocol.statistics.OFStatisticsType;
import org.openflow.util.HexString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AnalysisFlow extends Thread implements IOFMessageListener {
    
    protected String diretorioArquivos = "/mnt/armazem/openflow/tmp/dadosSwitchesOF/";
    protected String nomeArquivo = "PortStats";
    protected String nomeDB = "teste.db";


    protected IBeaconProvider beaconProvider;

    protected static Logger log = LoggerFactory
            .getLogger(LearningSwitchTutorialSolution.class);

    public void startUp(IBeaconProvider bP) {
        this.beaconProvider = bP;
        beaconProvider.addOFMessageListener(OFType.STATS_REPLY, this);
        // this.start();
        log.trace("Starting AnalysisFlow");
    }

    public void shutDown() {
        log.trace("Stopping AnalysisFlow");

    }

    @Override
    public Command receive(IOFSwitch sw, OFMessage msg) throws IOException {
        if (msg instanceof OFStatisticsReply) {
            log.debug("Recebendo mensagem de statisticas do sistema");
            OFStatisticsReply reply = (OFStatisticsReply) msg;

            // tem que ver o que vai fazer se for para porta se for para flow
            // etc... aqui s� esta tratando porta

            List<OFStatistics> stats = new ArrayList<OFStatistics>();
            stats = reply.getStatistics();

            // log.debug("------Classe stat={}",
            // stats.get(MIN_PRIORITY).getClass());
            if (stats.size() > 0) {
                if (stats.get(MIN_PRIORITY) instanceof OFFlowStatisticsReply) {
                    printFlowStats(sw, stats);
                }
                if (stats.get(MIN_PRIORITY) instanceof OFPortStatisticsReply) {
                    printPortStats(sw, stats);
                }
            }
        }
        return null;
    }

    /*
     * @Override public String getName() { // TODO Auto-generated method stub
     * return "AnalysisFlow"; }
     */

    /**
     * @param sw
     * @param stats
     */
    private void printPortStats(IOFSwitch sw, List<OFStatistics> stats) {
        for (int i = 0; i < stats.size(); i++) {
            OFPortStatisticsReply portReply = (OFPortStatisticsReply) stats
                    .get(i);
            // log.debug(
            // "Description Statistics Reply from {} / port {}: env {}/recv {}",
            // sw.getId(), portReply.getPortNumber(),
            // portReply.getTransmitBytes(), portReply.getReceiveBytes());

            String texto = getDataAtualMilisegundos() + "\t" + sw.getId()
                    + "\t" + portReply.getPortNumber() + "\t"
                    + portReply.getTransmitBytes() + "\t"
                    + portReply.getReceiveBytes();
            gravarArquivo(diretorioArquivos+nomeArquivo, texto);

            try {
                
                StatusPorta statusPorta = new StatusPorta();
                statusPorta.setTodosCamposDeStatisticas(sw.getId(), getDataAtualMilisegundos(), portReply);                
                StatusPortaDAO statusPortaDAO = new StatusPortaDAO(diretorioArquivos+nomeDB);
                statusPortaDAO.insert(statusPorta);
                statusPortaDAO.close();
            } catch (ClassNotFoundException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            
            //printPortsStatisticsDAO();
            
            
            /*Connection c;
            Statement stmt;
            try {
                Class.forName("org.sqlite.JDBC");
                c = DriverManager.getConnection("jdbc:sqlite:"
                        + diretorioArquivos + "teste.db");
                
                stmt = (Statement) c.createStatement();
                String sql = "INSERT INTO ports (" +
                        "switchNumber,"+
                        "portNumber,"+
                        "collisions,"+
                        "receiveBytes,"+
                        "receiveCRCErrors,"+
                        "receiveDropped,"+
                        "receiveErrors,"+
                        "receiveFrameErrors,"+
                        "receiveOverrunErrors,"+
                        "receivePackets,"+
                        "transmitBytes,"+
                        "transmitDropped,"+
                        "transmitErrors,"+
                        "transmitPackets,"+
                        "tempo"+
                        ")" +
                        "VALUES ("+
                            sw.getId()+","+
                            portReply.getPortNumber()+","+
                            portReply.getCollisions()+","+
                            portReply.getReceiveBytes()+","+
                            portReply.getReceiveCRCErrors()+","+
                            portReply.getReceiveDropped()+","+
                            portReply.getreceiveErrors()+","+
                            portReply.getReceiveFrameErrors()+","+
                            portReply.getReceiveOverrunErrors()+","+
                            portReply.getreceivePackets()+","+
                            portReply.getTransmitBytes()+","+
                            portReply.getTransmitDropped()+","+
                            portReply.getTransmitErrors()+","+
                            portReply.getTransmitPackets()+","+
                            getDataAtualMilisegundos()+
                            ");";
                stmt.executeUpdate(sql);  
                stmt.close();
                c.close();
                
            } catch (ClassNotFoundException e) {
                log.debug("Erro ao acessar JDBC");
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SQLException e) {
                log.debug(
                        "Erro ao tentar conectar ao banco de dados no arquivo {}",
                        diretorioArquivos + "teste.db");
                // TODO Auto-generated catch block
                e.printStackTrace();

            }*/

        }
    }

    /**
     * imprime as statisticas das portas dos switches extraidas do banco de dados
     */
    private void printPortsStatisticsDAO() {
        Vector<StatusPorta> vetorStatusPorta = new Vector<StatusPorta>();
        StatusPortaDAO sPDao;
        try {
            sPDao = new StatusPortaDAO(diretorioArquivos + nomeDB);
            vetorStatusPorta = sPDao.getAll();
            for(StatusPorta sP : vetorStatusPorta) {
                log.debug("Sw={}, PortNumber={}, BytesRx={}, PacketsRx={}, BytesTx={}, PacketsTx={}",
                        sP.getSwID(),sP.getPortNumber(),sP.getReceiveBytes(),sP.getreceivePackets(),
                        sP.getTransmitBytes(),sP.getTransmitPackets());
            }
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * @return retorna data atual do sistema
     */
    private long getDataAtualMilisegundos() {
        // Calendar cal = new GregorianCalendar();
        // Date date = new Date();
        // cal.setTime(date);
        // return cal.getTimeInMillis();
        return new Date().getTime();
    }

    /**
     * @param nomeArquivo
     *            Nome do Arquivo a ser gravado
     * @param texto
     *            Conte�do a ser gravado
     */
    private void gravarArquivo(String nomeArquivo, String texto) {
        try {

            FileWriter fstream = new FileWriter(nomeArquivo, true);
            BufferedWriter out = new BufferedWriter(fstream);
            out.write(texto);
            out.write("\n");
            out.close();
        } catch (IOException e) { // TODO Auto-generated catch block
            e.printStackTrace();
            log.debug("Aten��o! n�o foi poss�vel gravar o arquivo: {}",
                    nomeArquivo);
        }
    }

    /**
     * @param sw
     * @param stats
     */
    private void printFlowStats(IOFSwitch sw, List<OFStatistics> stats) {
        for (int i = 0; i < stats.size(); i++) {
            OFFlowStatisticsReply flowReply = (OFFlowStatisticsReply) stats
                    .get(i);
            /*
             * log.debug(
             * "Description Statistics Reply from tableId {} / packetCount {}: env {}/duration {}"
             * , sw.getId(), flowReply.getTableId(), flowReply.getPacketCount(),
             * flowReply.getDurationSeconds());
             */

            OFMatch match = new OFMatch();
            match = flowReply.getMatch();

            log.debug(
                    "in port: {}, HwSrc: {}, HwDst: {}, IPSrc:{}:{}, IPDst:{}:{}, Proto:{}, bytes:{}, packets:{}",
                    match.getInputPort(),
                    HexString.toHexString(match.getDataLayerSource()),
                    HexString.toHexString(match.getDataLayerDestination()),
                    IPv4.fromIPv4Address(match.getNetworkSource()),
                    match.getTransportSource(),
                    IPv4.fromIPv4Address(match.getNetworkDestination()),
                    match.getTransportDestination(),
                    match.getNetworkProtocol(), flowReply.getByteCount(),
                    flowReply.getPacketCount());

            /*
             * log.debug("\t{}:{} -> {}:{} - proto: {}",
             * IPv4.fromIPv4Address(match.getNetworkSource()),
             * match.getTransportSource(),
             * IPv4.fromIPv4Address(match.getNetworkDestination()),
             * match.getTransportDestination(), match.getNetworkProtocol());
             */

        }
    }

    /**
     * @param sw
     */
    private void getPortStatistics(IOFSwitch sw) {
        OFStatisticsRequest req = new OFStatisticsRequest();
        OFPortStatisticsRequest psr = new OFPortStatisticsRequest();
        psr.setPortNumber(OFPort.OFPP_NONE.getValue());
        req.setStatisticType(OFStatisticsType.PORT);
        req.setStatistics(psr);
        req.setLengthU(req.getLengthU() + psr.getLength());

        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param sw
     */
    private void getFlowStatistics(IOFSwitch sw) {

        OFStatisticsRequest req = new OFStatisticsRequest();
        OFFlowStatisticsRequest ofFlowRequest = new OFFlowStatisticsRequest();

        OFMatch match = new OFMatch();
        match.setWildcards(0xffffffff);

        ofFlowRequest.setMatch(match);
        ofFlowRequest.setOutPort(OFPort.OFPP_NONE.getValue());
        ofFlowRequest.setTableId((byte) 0xff);

        req.setStatisticType(OFStatisticsType.FLOW);
        req.setStatistics(ofFlowRequest);
        req.setLengthU(req.getLengthU() + ofFlowRequest.getLength());

        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 
     */
    public void run() {
        log.debug("Envia mensagens de pedido de status");
        while (true) {
            // intervalo de tempo que o sistema ira fazer a requisi��o de status
            // dos switchs
            int tempoSegundos = 3;
            esperaTempo(tempoSegundos);
            if (beaconProvider.getListeningIPAddress().isAnyLocalAddress()) {
                /*
                 * log.debug("IP do Switch: {} - porta {}",
                 * IPv4.fromIPv4Address(
                 * beaconProvider.getListeningIPAddress().getAddress()),
                 * beaconProvider.getListeningPort());
                 */
                // mostra os switches que est�o na rede!
                // log.debug("switches={}", beaconProvider.getSwitches());

                Map<String, Object> model = new HashMap<String, Object>();
                model.put("switches", beaconProvider.getSwitches().values());

                Collection<IOFSwitch> col = beaconProvider.getSwitches()
                        .values();
                for (IOFSwitch s : col) {
                    log.debug("switchId={}", s.getId());
                    IOFSwitch sw = beaconProvider.getSwitches().get(s.getId());
                    getFlowStatistics(sw);
                    esperaTempo(1);
                    getPortStatistics(sw);
                }
            } else {
                log.debug("Aten��o - N�o existem Switches dispon�veis na rede - imposs�vel obter status");
            }
        }

    }

    /**
     * @param tempoSegundos
     *            tempo que o programa ficara aguardando em segundos
     */
    private void esperaTempo(int tempoSegundos) {
        try {
            sleep(tempoSegundos * 1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

}
