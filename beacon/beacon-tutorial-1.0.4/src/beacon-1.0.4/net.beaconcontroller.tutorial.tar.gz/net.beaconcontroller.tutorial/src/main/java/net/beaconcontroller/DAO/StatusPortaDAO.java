package net.beaconcontroller.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import net.beaconcontroller.tutorial.LearningSwitchTutorialSolution;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StatusPortaDAO {
    private Connection c;
    private Statement stmt;
    protected static Logger log = LoggerFactory.getLogger(LearningSwitchTutorialSolution.class);
    
    public StatusPortaDAO(String arquivo) throws ClassNotFoundException, SQLException {
        log.debug("Iniciando banco de dados");
        Class.forName("org.sqlite.JDBC");
        c = DriverManager.getConnection("jdbc:sqlite:"+arquivo);
        stmt = (Statement) c.createStatement();
    }
    
    public void close() throws SQLException {
        log.debug("Fechando banco de dados");
        stmt.close();
        c.close();
    }
    
    public void insert(StatusPorta statusPorta) throws SQLException {
        log.debug("Inserindo no bando de dados");
        String sql = "INSERT INTO ports (" +
                "switchNumber,"+
                "portNumber,"+
                "collisions,"+
                "receiveBytes,"+
                "receiveCRCErrors,"+
                "receiveDropped,"+
                "receiveErrors,"+
                "receiveFrameErrors,"+
                "receiveOverrunErrors,"+
                "receivePackets,"+
                "transmitBytes,"+
                "transmitDropped,"+
                "transmitErrors,"+
                "transmitPackets,"+
                "tempo"+
                ")" +
                "VALUES ("+
                    statusPorta.getSwID()+","+
                    statusPorta.getPortNumber()+","+
                    statusPorta.getCollisions()+","+
                    statusPorta.getReceiveBytes()+","+
                    statusPorta.getReceiveCRCErrors()+","+
                    statusPorta.getReceiveDropped()+","+
                    statusPorta.getreceiveErrors()+","+
                    statusPorta.getReceiveFrameErrors()+","+
                    statusPorta.getReceiveOverrunErrors()+","+
                    statusPorta.getreceivePackets()+","+
                    statusPorta.getTransmitBytes()+","+
                    statusPorta.getTransmitDropped()+","+
                    statusPorta.getTransmitErrors()+","+
                    statusPorta.getTransmitPackets()+","+
                    statusPorta.getTempo()+
                    ");";
        stmt.executeUpdate(sql);  
    }
    
    
    /**
     * 
     * @return retorna uma lista com o objeto StatusPorta provinda do banco de dados
     * @throws SQLException
     */
    public Vector<StatusPorta> getAll() throws SQLException {
        Vector<StatusPorta> lista = new Vector<StatusPorta>();
        ResultSet result;
        String sql = "SELECT * FROM ports";
        result = this.stmt.executeQuery(sql);
        while (result.next()) {
            StatusPorta statusPorta = new StatusPorta();
            statusPorta.setSwID(result.getInt("switchNumber"));
            statusPorta.setTempo(result.getLong("tempo"));
            statusPorta.setPortNumber((short)result.getInt("portNumber"));
            statusPorta.setCollisions(result.getLong("collisions"));
            statusPorta.setReceiveBytes(result.getLong("receiveBytes"));
            statusPorta.setReceiveCRCErrors(result.getLong("receiveCRCErrors"));
            statusPorta.setReceiveDropped(result.getLong("receiveDropped"));
            statusPorta.setreceiveErrors(result.getLong("receiveErrors"));
            statusPorta.setReceiveFrameErrors(result.getLong("receiveFrameErrors"));
            statusPorta.setReceiveOverrunErrors(result.getLong("receiveOverrunErrors"));
            statusPorta.setreceivePackets(result.getLong("receivePackets"));
            statusPorta.setTransmitBytes(result.getLong("transmitBytes"));
            statusPorta.setTransmitDropped(result.getLong("transmitDropped"));
            statusPorta.setTransmitErrors(result.getLong("transmitErrors"));
            statusPorta.setTransmitPackets(result.getLong("transmitPackets"));
            lista.add(statusPorta);
        }
        
        return lista;
    }
    
    
    

}
