/**
 * Copyright 2010-2013, Stanford University. This file is licensed under the
 * BSD license as described in the included LICENSE.txt.
 */
package net.beaconcontroller.tutorial;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import net.beaconcontroller.core.IBeaconProvider;
import net.beaconcontroller.core.IOFMessageListener;
import net.beaconcontroller.core.IOFSwitch;
import net.beaconcontroller.core.IOFSwitchListener;
import net.beaconcontroller.packet.Ethernet;
import net.beaconcontroller.packet.IPv4;

import org.openflow.protocol.OFFlowMod;
import org.openflow.protocol.OFMatch;
import org.openflow.protocol.OFMessage;
import org.openflow.protocol.OFPacketIn;
import org.openflow.protocol.OFPacketOut;
import org.openflow.protocol.OFPort;
import org.openflow.protocol.OFStatisticsRequest;
import org.openflow.protocol.OFType;
import org.openflow.protocol.action.OFAction;
import org.openflow.protocol.action.OFActionEnqueue;
import org.openflow.protocol.action.OFActionOutput;
import org.openflow.protocol.statistics.OFFlowStatisticsReply;
import org.openflow.protocol.statistics.OFFlowStatisticsRequest;
import org.openflow.protocol.statistics.OFPortStatisticsReply;
import org.openflow.protocol.statistics.OFPortStatisticsRequest;
import org.openflow.protocol.statistics.OFStatistics;
import org.openflow.protocol.statistics.OFStatisticsType;
import org.openflow.util.HexString;
import org.openflow.util.U16;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ola Tutorial class used to teach how to build a simple layer 2 learning switch.
 * 
 * @author David Erickson (daviderickson@cs.stanford.edu) - 10/14/12
 */
public class LearningSwitchTutorialSolution implements IOFMessageListener,
        IOFSwitchListener {
    protected static Logger log = LoggerFactory
            .getLogger(LearningSwitchTutorialSolution.class);
    protected IBeaconProvider beaconProvider;
    protected Map<IOFSwitch, Map<Long, Short>> macTables = new HashMap<IOFSwitch, Map<Long, Short>>();

    public Command receive(IOFSwitch sw, OFMessage msg) throws IOException {
        initMACTable(sw);
        if (msg instanceof OFPacketIn) {
            OFPacketIn pi = (OFPacketIn) msg;
            // forwardAsHub(sw, pi);
            forwardAsLearningSwitchWithFirewall(sw, pi);

            //getPortStatistics(sw);
            //getFlowStatistics(sw);
        }

        // RECEIVE STATISTICS REPLY

        // log.debug("Classe de msg = {} -- type = {}",
        // msg.getClass(),msg.getType());

        /*if (msg instanceof OFStatisticsReply) {
            log.debug("RECEIVED STATISTIC REPLY !!!");
            OFStatisticsReply reply = (OFStatisticsReply) msg;

            // tem que ver o que vai fazer se for para porta se for para flow
            // etc... aqui s� esta tratando porta

            List<OFStatistics> stats = new ArrayList<OFStatistics>();
            stats = reply.getStatistics();

            //printPortStats(sw, stats);
            printFlowStats(sw, stats);
        }*/

        return Command.CONTINUE;
    }

    /**
     * @param sw
     * @param stats
     */
    private void printPortStats(IOFSwitch sw, List<OFStatistics> stats) {
        for (int i = 0; i < stats.size(); i++) {
            OFPortStatisticsReply portReply = (OFPortStatisticsReply) stats
                    .get(i);
            log.debug(
                    "Description Statistics Reply from {} / port {}: env {}/recv {}",
                    sw.getId(), portReply.getPortNumber(),
                    portReply.getTransmitBytes(), portReply.getReceiveBytes());
        }
    }

    /**
     * @param sw
     * @param stats
     */
    private void printFlowStats(IOFSwitch sw, List<OFStatistics> stats) {
        for (int i = 0; i < stats.size(); i++) {
            OFFlowStatisticsReply flowReply = (OFFlowStatisticsReply) stats
                    .get(i);
/*            log.debug(
                    "Description Statistics Reply from tableId {} / packetCount {}: env {}/duration {}",
                    sw.getId(), flowReply.getTableId(),
                    flowReply.getPacketCount(), flowReply.getDurationSeconds());*/
            
            
            OFMatch match = new OFMatch();
            match = flowReply.getMatch();
            
            log.debug("in port: {}, HwSrc: {}, HwDst: {}, IPSrc:{}:{}, IPDst:{}:{}, Proto:{}, bytes:{}, packets:{}",
                    match.getInputPort(), HexString.toHexString(match.getDataLayerSource()), HexString.toHexString(match.getDataLayerDestination()),
                    IPv4.fromIPv4Address(match.getNetworkSource()), match.getTransportSource(), 
                    IPv4.fromIPv4Address(match.getNetworkDestination()), match.getTransportDestination(), 
                    match.getNetworkProtocol(),
                    flowReply.getByteCount(),
                    flowReply.getPacketCount()
                    );
            
            
            /*log.debug("\t{}:{} -> {}:{} - proto: {}", IPv4.fromIPv4Address(match.getNetworkSource()),
                    match.getTransportSource(), IPv4.fromIPv4Address(match.getNetworkDestination()),
                    match.getTransportDestination(), match.getNetworkProtocol());
                    */

        }
    }

    /**
     * @param sw
     */
    private void getPortStatistics(IOFSwitch sw) {
        OFStatisticsRequest req = new OFStatisticsRequest();
        OFPortStatisticsRequest psr = new OFPortStatisticsRequest();
        psr.setPortNumber(OFPort.OFPP_NONE.getValue());
        req.setStatisticType(OFStatisticsType.PORT);
        req.setStatistics(psr);
        req.setLengthU(req.getLengthU() + psr.getLength());

        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param sw
     */
    private void getFlowStatistics(IOFSwitch sw) {

        OFStatisticsRequest req = new OFStatisticsRequest();
        OFFlowStatisticsRequest ofFlowRequest = new OFFlowStatisticsRequest();

        OFMatch match = new OFMatch();
        match.setWildcards(0xffffffff);

        ofFlowRequest.setMatch(match);
        ofFlowRequest.setOutPort(OFPort.OFPP_NONE.getValue());
        ofFlowRequest.setTableId((byte) 0xff);

        req.setStatisticType(OFStatisticsType.FLOW);
        req.setStatistics(ofFlowRequest);
        req.setLengthU(req.getLengthU() + ofFlowRequest.getLength());

        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * EXAMPLE CODE: Floods the packet out all switch ports except the port it
     * came in on.
     * 
     * @param sw
     *            the OpenFlow switch object
     * @param pi
     *            the OpenFlow Packet In object
     * @throws IOException
     */
    public void forwardAsHub(IOFSwitch sw, OFPacketIn pi) throws IOException {
        // Create the OFPacketOut OpenFlow object
        OFPacketOut po = new OFPacketOut();

        // Create an output action to flood the packet, put it in the
        // OFPacketOut
        OFAction action = new OFActionOutput(OFPort.OFPP_FLOOD.getValue());
        po.setActions(Collections.singletonList(action));

        // Set the port the packet originally arrived on
        po.setInPort(pi.getInPort());

        OFMatch match = new OFMatch();
        match.loadFromPacket(pi.getPacketData(), (short) 0);
        /*
         * log.info("PortIn {}:", pi.getInPort());
         * log.info("L2  type {}, {}->{}",match.getDataLayerType(),
         * HexString.toHexString
         * (match.getDataLayerSource()),HexString.toHexString
         * (match.getDataLayerDestination()));
         * log.info("L3 proto {}, {}->{}",match
         * .getNetworkProtocol(),IPv4.fromIPv4Address
         * (match.getNetworkSource()),IPv4
         * .fromIPv4Address(match.getNetworkDestination()));
         */
        // Reference the packet buffered at the switch by id
        po.setBufferId(pi.getBufferId());
        if (pi.getBufferId() == OFPacketOut.BUFFER_ID_NONE) {
            /**
             * The packet was NOT buffered at the switch, therefore we must copy
             * the packet's data from the OFPacketIn to our new OFPacketOut
             * message.
             */
            po.setPacketData(pi.getPacketData());
        }
        // Send the OFPacketOut to the switch

        // if faz um firewall...
        /*
         * if(IPv4.fromIPv4Address(match.getNetworkSource()).equals("10.0.0.1"))
         * { log.info("Boqueia"); log.info("\tPortIn {}:", pi.getInPort());
         * log.info("\tL2  type {}, {}->{}",match.getDataLayerType(),
         * HexString.toHexString
         * (match.getDataLayerSource()),HexString.toHexString
         * (match.getDataLayerDestination()));
         * log.info("\tL3 proto {}, {}->{}",match
         * .getNetworkProtocol(),IPv4.fromIPv4Address
         * (match.getNetworkSource()),IPv4
         * .fromIPv4Address(match.getNetworkDestination())); } else
         */
        sw.getOutputStream().write(po);
    }

    /**
     * Learn the source MAC:port pair for each arriving packet, and send packets
     * out the port previously learned for the destination MAC of the packet, if
     * it exists. Otherwise flood the packet similarly to forwardAsHub.
     * 
     * @param sw
     *            the OpenFlow switch object
     * @param pi
     *            the OpenFlow Packet In object
     * @throws IOException
     */
    public void forwardAsLearningSwitch(IOFSwitch sw, OFPacketIn pi)
            throws IOException {
        Map<Long, Short> macTable = macTables.get(sw);

        // Build the Match
        OFMatch match = OFMatch.load(pi.getPacketData(), pi.getInPort());

        // Learn the port to reach the packet's source MAC
        macTable.put(Ethernet.toLong(match.getDataLayerSource()),
                pi.getInPort());

        // Retrieve the port previously learned for the packet's dest MAC
        Short outPort = macTable.get(Ethernet.toLong(match
                .getDataLayerDestination()));

        if (outPort != null) {
            // Destination port known, push down a flow
            OFFlowMod fm = new OFFlowMod();
            fm.setBufferId(pi.getBufferId());
            // Use the Flow ADD command
            fm.setCommand(OFFlowMod.OFPFC_ADD);
            // Time out the flow after 5 seconds if inactivity
            fm.setIdleTimeout((short) 5);
            // Match the packet using the match created above
            fm.setMatch(match);
            // Send matching packets to outPort
            OFAction action = new OFActionOutput(outPort);
            fm.setActions(Collections.singletonList((OFAction) action));
            // Send this OFFlowMod to the switch
            sw.getOutputStream().write(fm);

            if (pi.getBufferId() == OFPacketOut.BUFFER_ID_NONE) {
                /**
                 * EXTRA CREDIT: This is a corner case, the packet was not
                 * buffered at the switch so it must be sent as an OFPacketOut
                 * after sending the OFFlowMod
                 */
                OFPacketOut po = new OFPacketOut();
                action = new OFActionOutput(outPort);
                po.setActions(Collections.singletonList(action));
                po.setBufferId(OFPacketOut.BUFFER_ID_NONE);
                po.setInPort(pi.getInPort());
                po.setPacketData(pi.getPacketData());
                sw.getOutputStream().write(po);
            }
        } else {
            // Destination port unknown, flood packet to all ports
            forwardAsHub(sw, pi);
        }
    }


    public void forwardAsLearningSwitchWithFirewall(IOFSwitch sw, OFPacketIn pi)
            throws IOException {
        Map<Long, Short> macTable = macTables.get(sw);

        // Build the Match
        OFMatch match = OFMatch.load(pi.getPacketData(), pi.getInPort());

        // log.debug("CB -> Data Layer Source: {} - Input Port: {} ",
        // match.getDataLayerSource(), match.getInputPort());

        // log.debug("Switch -> {} ",sw.getId());

        // Learn the port to reach the packet's source MAC
        macTable.put(Ethernet.toLong(match.getDataLayerSource()),
                pi.getInPort());

        // Retrieve the port previously learned for the packet's dest MAC
        Short outPort = macTable.get(Ethernet.toLong(match
                .getDataLayerDestination()));

        List<OFAction> act = new ArrayList<OFAction>();

        short flowModLength = (short) OFFlowMod.MINIMUM_LENGTH;

        if (outPort != null) {

            if (match.getTransportDestination() == 666
                    || match.getTransportSource() == 666) {

                log.debug("Combinou enqueue 666");
                if (match.getTransportDestination() == 666
                        || match.getTransportSource() == 666) {

                    log.debug("Combinou enqueue 666");

                    OFActionEnqueue actionEnque = new OFActionEnqueue();

                    actionEnque.setPort(outPort);

                    actionEnque.setQueueId(1); // the queue id to be used

                    flowModLength += OFActionEnqueue.MINIMUM_LENGTH;

                    act.add(actionEnque);

                    OFFlowMod fm = (OFFlowMod) sw.getInputStream()
                            .getMessageFactory().getMessage(OFType.FLOW_MOD);

                    fm.setBufferId(-1).setIdleTimeout((short) 100)

                    .setHardTimeout((short) 100)

                    .setOutPort((short) OFPort.OFPP_ALL.getValue())

                    .setMatch(match).setActions(act)

                    .setLength(U16.t(flowModLength));

                    try {

                        sw.getOutputStream().write(fm);

                    } catch (IOException e) {

                        log.error("Unable to write flow mod package. {}", e);

                    }

                } else {

                    // Destination port known, push down a flow
                    OFFlowMod fm = new OFFlowMod();
                    fm.setBufferId(pi.getBufferId());
                    // Use the Flow ADD command
                    fm.setCommand(OFFlowMod.OFPFC_ADD);
                    // Time out the flow after 5 seconds if inactivity
                    fm.setIdleTimeout((short) 5);
                    // Match the packet using the match created above
                    fm.setMatch(match);
                    // Send matching packets to outPort
                    OFAction action = new OFActionOutput(outPort);
                    fm.setActions(Collections.singletonList((OFAction) action));
                    // Send this OFFlowMod to the switch
                    sw.getOutputStream().write(fm);

                    if (pi.getBufferId() == OFPacketOut.BUFFER_ID_NONE) {
                        /**
                         * EXTRA CREDIT: This is a corner case, the packet was
                         * not buffered at the switch so it must be sent as an
                         * OFPacketOut after sending the OFFlowMod
                         */
                        OFPacketOut po = new OFPacketOut();
                        action = new OFActionOutput(outPort);
                        po.setActions(Collections.singletonList(action));
                        po.setBufferId(OFPacketOut.BUFFER_ID_NONE);
                        po.setInPort(pi.getInPort());
                        po.setPacketData(pi.getPacketData());
                        sw.getOutputStream().write(po);
                    }
                }
                OFActionEnqueue actionEnque = new OFActionEnqueue();

                actionEnque.setPort(outPort);

                actionEnque.setQueueId(1); // the queue id to be used

                flowModLength += OFActionEnqueue.MINIMUM_LENGTH;

                act.add(actionEnque);

                OFFlowMod fm = (OFFlowMod) sw.getInputStream()
                        .getMessageFactory().getMessage(OFType.FLOW_MOD);

                fm.setBufferId(-1).setIdleTimeout((short) 100)

                .setHardTimeout((short) 100)

                .setOutPort((short) OFPort.OFPP_ALL.getValue())

                .setMatch(match).setActions(act)

                .setLength(U16.t(flowModLength));

                try {

                    sw.getOutputStream().write(fm);

                } catch (IOException e) {

                    log.error("Unable to write flow mod package. {}", e);

                }

            } else {

                // Destination port known, push down a flow
                OFFlowMod fm = new OFFlowMod();
                fm.setBufferId(pi.getBufferId());
                // Use the Flow ADD command
                fm.setCommand(OFFlowMod.OFPFC_ADD);
                // Time out the flow after 5 seconds if inactivity
                fm.setIdleTimeout((short) 5);
                // Match the packet using the match created above
                fm.setMatch(match);
                // Send matching packets to outPort
                OFAction action = new OFActionOutput(outPort);
                fm.setActions(Collections.singletonList((OFAction) action));
                // Send this OFFlowMod to the switch
                sw.getOutputStream().write(fm);

                // teste

                // fim teste

                if (pi.getBufferId() == OFPacketOut.BUFFER_ID_NONE) {
                    /**
                     * EXTRA CREDIT: This is a corner case, the packet was not
                     * buffered at the switch so it must be sent as an
                     * OFPacketOut after sending the OFFlowMod
                     */
                    OFPacketOut po = new OFPacketOut();
                    action = new OFActionOutput(outPort);
                    po.setActions(Collections.singletonList(action));
                    po.setBufferId(OFPacketOut.BUFFER_ID_NONE);
                    po.setInPort(pi.getInPort());
                    po.setPacketData(pi.getPacketData());
                    sw.getOutputStream().write(po);
                }
            }

        } else {
            // Destination port unknown, flood packet to all ports
            forwardAsHub(sw, pi);
        }
    }


    // ---------- NO NEED TO EDIT ANYTHING BELOW THIS LINE ----------

    /**
     * Ensure there is a MAC to port table per switch
     * 
     * @param sw
     */
    private void initMACTable(IOFSwitch sw) {
        Map<Long, Short> macTable = macTables.get(sw);
        if (macTable == null) {
            macTable = new HashMap<Long, Short>();
            macTables.put(sw, macTable);
        }
    }

    @Override
    public void addedSwitch(IOFSwitch sw) {

    }

    @Override
    public void removedSwitch(IOFSwitch sw) {
        macTables.remove(sw);
    }

    /**
     * @param beaconProvider
     *            the beaconProvider to set
     */
    public void setBeaconProvider(IBeaconProvider beaconProvider) {
        this.beaconProvider = beaconProvider;
    }

    public void startUp() {
        log.trace("=======================Starting");
        // beaconProvider.addOFMessageListener(OFType.PACKET_IN, this);
        beaconProvider.addOFMessageListener(OFType.PACKET_IN, this);
        beaconProvider.addOFMessageListener(OFType.STATS_REPLY, this);
        beaconProvider.addOFSwitchListener(this);
        
        //EnviaStatusRequest enviaStatusRequest = new EnviaStatusRequest();
        //enviaStatusRequest.startUp(beaconProvider);

        AnalysisFlow analysisFlow = new AnalysisFlow();
        analysisFlow.startUp(beaconProvider);
        analysisFlow.start();
        
        
        // log.debug("IDSwitch:{}",String.valueOf(new Long(sw.getId())));
        // 00:00:00:00:00:00:00:01
        // analysisFlow.startUp(String.valueOf(new Long(sw.getId())));
        // analysisFlow.startUp("00:00:00:00:00:00:00:01");

    }

    public void shutDown() {
        log.trace("Stopping");
        beaconProvider.removeOFMessageListener(OFType.PACKET_IN, this);
        beaconProvider.removeOFMessageListener(OFType.STATS_REPLY, this);
        beaconProvider.removeOFSwitchListener(this);
    }

    public String getName() {
        return "tutorial";
    }

    // teste

    // final teste

}
