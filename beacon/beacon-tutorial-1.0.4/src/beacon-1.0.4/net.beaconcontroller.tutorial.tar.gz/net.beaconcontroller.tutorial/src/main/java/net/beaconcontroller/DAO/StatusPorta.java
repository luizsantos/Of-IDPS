package net.beaconcontroller.DAO;

import org.openflow.protocol.statistics.OFPortStatisticsReply;

public class StatusPorta extends OFPortStatisticsReply {
    protected long swID;
    protected long tempo;
    
    
    public long getSwID() {
        return swID;
    }
    
    /**
     * @param swID Numero do Switch, esse campo � obrigat�rio no banco de dados
     */
    public void setSwID(long swID) {
        this.swID = swID;
    }
    public long getTempo() {
        return tempo;
    }
    public void setTempo(long tempo) {
        this.tempo = tempo;
    }
        
    /**
     * @param iDdoSWitch Numero de identifica��o do switch, esse campo � obrigat�rio no banco de dados
     * @param tempoMensagem Hora em milessegundos que a mensagem de status foi coletada
     * @param status Objeto OFPortStaticsReply para preencher os campos de statisticas a partir do objeto original/pai
     * 
     * Utilize apenas esse m�todo para "setar" os dados do objeto.
     */
    public void setTodosCamposDeStatisticas(long iDdoSwitch, long tempoMensagem, OFPortStatisticsReply status){
        this.setSwID(iDdoSwitch);
        this.setTempo(tempoMensagem);
        this.setCollisions(status.getCollisions());
        this.setPortNumber(status.getPortNumber());
        this.setReceiveBytes(status.getReceiveBytes());
        this.setReceiveCRCErrors(status.getReceiveCRCErrors());
        this.setReceiveDropped(status.getReceiveDropped());
        this.setreceiveErrors(status.getreceiveErrors());
        this.setReceiveFrameErrors(status.getReceiveFrameErrors());
        this.setReceiveOverrunErrors(status.getReceiveOverrunErrors());
        this.setreceivePackets(status.getreceivePackets());
        this.setTransmitBytes(status.getTransmitBytes());
        this.setTransmitDropped(status.getTransmitDropped());
        this.setTransmitErrors(status.getTransmitErrors());
        this.setTransmitPackets(status.getTransmitPackets());
    }
}
