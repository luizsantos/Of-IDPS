package net.beaconcontroller.uteis;

public class ProtocolsNumbers {
    public static final int IP      = 0;
    public static final int ICMP    = 1;
    public static final int TCP     = 6;
    public static final int UDP     = 17;

    

}
