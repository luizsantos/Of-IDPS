package net.beaconcontroller.uteis;

public class TempoData {
    
    

}
