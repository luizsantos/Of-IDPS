package net.beaconcontroller.uteis;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.logging.FileHandler;

import net.beaconcontroller.tutorial.LearningSwitchTutorialSolution;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 
 * @author luiz
 * 
 * TODO !DUVIDA! Neste sempre que eu gravo eu abro e fecho o arquivo, n�o sei qual � a efici�ncia disso! ver com o Rodrigo
 *
 */

public class Arquivo {

    private String nomeArquivo; // nome apenas do arquivo
    private String nomeDiretorio; // nome apenas do diret�rio
    private String pathArquivo; // nome completo (diret�rio + arquivo)

    protected static Logger log = LoggerFactory
            .getLogger(LearningSwitchTutorialSolution.class);

    
    /**
     * 
     * @param nomeDiretorio -  nome do dire�rio a gravar/ler o arquivo;
     * @param nomeArquivo - nome do arquivo a ser gravado/lido
     */
    public Arquivo(String nomeDiretorio, String nomeArquivo) {
        super();
        this.nomeArquivo = nomeArquivo;
        this.nomeDiretorio = nomeDiretorio;
        this.pathArquivo=nomeDiretorio+nomeArquivo;
    }

    /**
     * 
     * @param nomeArquivo - nome do arquivo a ser gravado/lido
     * 
     * neste o diret�rio onde o arquivo ser� gravado ser� o corrente
     */

    public Arquivo(String nomeArquivo) {
        super();
        this.nomeArquivo = nomeArquivo;
        this.nomeDiretorio = "./";
        this.pathArquivo=nomeDiretorio+nomeArquivo;
    }

    public String getPathArquivo() {
        return pathArquivo;
    }

    public String getNomeArquivo() {
        return nomeArquivo;
    }

    public void setNomeArquivo(String nomeArquivo) {
        this.nomeArquivo = nomeArquivo;
    }

    public String getNomeDiretorio() {
        return nomeDiretorio;
    }

    public void setNomeDiretorio(String nomeDiretorio) {
        this.nomeDiretorio = nomeDiretorio;
    }

    
    /**
     * @param nomeArquivo
     *            Nome do Arquivo a ser gravado
     * @param texto
     *            Conte�do a ser gravado
     */
    public void gravarArquivo(String texto) {
        try {
            FileWriter fstream = new FileWriter(this.pathArquivo, true);
            BufferedWriter out = new BufferedWriter(fstream);
            out.write(texto);
            out.write("\n");
            out.close();
        } catch (IOException e) { // TODO Auto-generated catch block
            e.printStackTrace();
            log.debug("Aten��o! n�o foi poss�vel gravar o arquivo: {}",
                    this.pathArquivo);
        }
    }
    
    public String lerArquivo( ) {
        String texto = "";
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader(this.pathArquivo));
            String linha;
            try {
                while ((linha = br.readLine()) != null) {
                    texto = texto + linha +"\n";
                }
            } catch (IOException e) {
                log.debug("Aten��o! linhas nulas no arquivo: {}",
                        this.pathArquivo);
            }

        } catch (FileNotFoundException e) {
            log.debug("Aten��o! n�o foi poss�vel ler o arquivo: {}",
                    this.pathArquivo);
        }
        return texto;
    }
    
    public String hashAquivo() {
        String conteudoArquivo = lerArquivo();
        MessageDigest md5;
        try {
            md5 = MessageDigest.getInstance("MD5");
            md5.update(conteudoArquivo.getBytes(), 0, conteudoArquivo.length());
            return new BigInteger(1, md5.digest()).toString();
        } catch (NoSuchAlgorithmException e) {
            log.debug("N�o foi poss�vel fazer hash do arquivo!");
        }
        return null;
    }
    
    /**
     * 
     * @return Falso caso j� exista e Verdadeiro caso n�o exista e seja criado
     */
    public boolean verificaSeArquivoExisteSeNaoCriarEsseArquivo() {
        File file = new File((this.pathArquivo));
        try {
            return file.createNewFile();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            log.debug("n�o foi poss�vel criar/ler arquivo {}!", this.pathArquivo);
        }
        return false; 
    }
    
}
