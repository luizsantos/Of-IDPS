package net.beaconcontroller.DAO;

import org.openflow.protocol.OFMatch;
import org.openflow.protocol.statistics.OFFlowStatisticsReply;

public class StatusFlow extends  OFFlowStatisticsReply {
    protected long swID;
    protected long tempo;
    protected byte[] dataLayerDestination;
    protected byte[] dataLayerSource;
    protected short dataLayerType;
    protected short dataLayerVirtualLan;
    protected byte dataLayerVirtualLanPriorityCodePoint;
    protected short inputPort;
    protected int networkDestination;
    protected byte networkProtocol;
    protected int networkSource;
    protected byte networkTypeOfService;
    protected short transportDestination ;
    protected short transportSource;
    protected int wildcards;
    
    
    
    public byte[] getDataLayerDestination() {
        return dataLayerDestination;
    }
    public void setDataLayerDestination(byte[] dataLayerDestination) {
        this.dataLayerDestination = dataLayerDestination;
    }
    public byte[] getDataLayerSource() {
        return dataLayerSource;
    }
    public void setDataLayerSource(byte[] dataLayerSource) {
        this.dataLayerSource = dataLayerSource;
    }
    public short getDataLayerType() {
        return dataLayerType;
    }
    public void setDataLayerType(short dataLayerType) {
        this.dataLayerType = dataLayerType;
    }
    public short getDataLayerVirtualLan() {
        return dataLayerVirtualLan;
    }
    public void setDataLayerVirtualLan(short dataLayerVirtualLan) {
        this.dataLayerVirtualLan = dataLayerVirtualLan;
    }
    public byte getDataLayerVirtualLanPriorityCodePoint() {
        return dataLayerVirtualLanPriorityCodePoint;
    }
    public void setDataLayerVirtualLanPriorityCodePoint(
            byte dataLayerVirtualLanPriorityCodePoint) {
        this.dataLayerVirtualLanPriorityCodePoint = dataLayerVirtualLanPriorityCodePoint;
    }
    public short getInputPort() {
        return inputPort;
    }
    public void setInputPort(short inputPort) {
        this.inputPort = inputPort;
    }
    public int getNetworkDestination() {
        return networkDestination;
    }
    public void setNetworkDestination(int networkDestination) {
        this.networkDestination = networkDestination;
    }
    public byte getNetworkProtocol() {
        return networkProtocol;
    }
    public void setNetworkProtocol(byte networkProtocol) {
        this.networkProtocol = networkProtocol;
    }
    public int getNetworkSource() {
        return networkSource;
    }
    public void setNetworkSource(int networkSource) {
        this.networkSource = networkSource;
    }
    public byte getNetworkTypeOfService() {
        return networkTypeOfService;
    }
    public void setNetworkTypeOfService(byte networkTypeOfService) {
        this.networkTypeOfService = networkTypeOfService;
    }
    public short getTransportDestination() {
        return transportDestination;
    }
    public void setTransportDestination(short transportDestination) {
        this.transportDestination = transportDestination;
    }
    public short getTransportSource() {
        return transportSource;
    }
    public void setTransportSource(short transportSource) {
        this.transportSource = transportSource;
    }
    public int getWildcards() {
        return wildcards;
    }
    public void setWildcards(int wildcards) {
        this.wildcards = wildcards;
    }
    public long getSwID() {
        return swID;
    }
    public void setSwID(long swID) {
        this.swID = swID;
    }
    public long getTempo() {
        return tempo;
    }
    public void setTempo(long tempo) {
        this.tempo = tempo;
    }
    
    public void setTodosCamposDeStatisticas(long iDdoSwitch, long tempoMensagem, OFFlowStatisticsReply status){
        this.setSwID(iDdoSwitch);
        this.setTempo(tempoMensagem);
        
        // faltou actionFactory
        // faltou actions
        this.setByteCount(status.getByteCount());
        this.setCookie(status.getCookie());
        this.setDurationNanoseconds(status.getDurationNanoseconds());
        this.setDurationSeconds(status.getDurationSeconds());
        this.setHardTimeout(status.getHardTimeout());
        this.setIdleTimeout(status.getIdleTimeout());
        this.setLength((short) status.getLength());
        this.setMatch(status.getMatch());
        //faltou MINIMUM_LENGTH
        this.setPacketCount(status.getPacketCount());
        this.setPriority(status.getPriority());
        this.setTableId(status.getTableId());
        
        OFMatch m = new OFMatch();
        m = status.getMatch();
        
        this.setDataLayerDestination(m.getDataLayerDestination());
        this.setDataLayerSource(m.getDataLayerSource());
        this.setDataLayerType(m.getDataLayerType());
        this.setDataLayerVirtualLan(m.getDataLayerVirtualLan());
        this.setDataLayerVirtualLanPriorityCodePoint(m.getDataLayerVirtualLanPriorityCodePoint());
        this.setInputPort(m.getInputPort());
        this.setNetworkDestination(m.getNetworkDestination());
        this.setNetworkProtocol(m.getNetworkProtocol());
        this.setNetworkSource(m.getNetworkSource());
        this.setNetworkTypeOfService(m.getNetworkTypeOfService());
        this.setTransportDestination(m.getTransportDestination());
        this.setTransportSource(m.getTransportSource());
        this.setWildcards(m.getWildcards());
        
    }
}
