package net.beaconcontroller.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import net.beaconcontroller.tutorial.LearningSwitchTutorialSolution;

import org.openflow.util.HexString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StatusFlowDAO {
    private Connection c;
    private Statement stmt;
    protected static Logger log = LoggerFactory.getLogger(LearningSwitchTutorialSolution.class);

    public StatusFlowDAO(String arquivo) throws ClassNotFoundException, SQLException {
       // log.debug("Iniciando banco de dados");
        Class.forName("org.sqlite.JDBC");
        c = DriverManager.getConnection("jdbc:sqlite:"+arquivo);
        stmt = (Statement) c.createStatement();
    }
    
    public void close() throws SQLException {
        //log.debug("Fechando banco de dados");
        stmt.close();
        c.close();
    }
    
    public void insert(StatusFlow sf) throws SQLException {
        //log.debug("Inserindo no bando de dados");
        String sql = "INSERT INTO flows ("+
                "swID,"+
                "tempo,"+
                "byteCount,"+
                "cookie,"+
                "durationNanoseconds,"+
                "durationSeconds,"+
                "hardTimeout,"+
                "idleTimeout,"+
                "length,"+
                "packetCount,"+
                "priority,"+
                "tableId,"+
                "dataLayerDestination,"+
                "dataLayerSource,"+
                "dataLayerType,"+
                "dataLayerVirtualLan,"+
                "dataLayerVirtualLanPriorityCodePoint,"+
                "inputPort,"+
                "networkDestination,"+
                "networkProtocol,"+
                "networkSource,"+
                "networkTypeOfService,"+
                "transportDestination,"+
                "transportSource,"+
                "Wildcards"+
                ")" +
                " VALUES ("+
                    sf.getSwID()+","+
                    sf.getTempo()+","+
                    sf.getByteCount()+","+
                    sf.getCookie()+","+
                    sf.getDurationNanoseconds()+","+
                    sf.getDurationSeconds()+","+
                    sf.getHardTimeout()+","+
                    sf.getIdleTimeout()+","+
                    sf.getLength()+","+
                    sf.getPacketCount()+","+
                    sf.getPriority()+","+
                    sf.getTableId()+","+
                    '\''+HexString.toHexString(sf.getDataLayerDestination())+'\''+","+
                    '\''+HexString.toHexString(sf.getDataLayerSource())+'\''+","+
                    sf.getDataLayerType()+","+
                    sf.getDataLayerVirtualLan()+","+
                    sf.getDataLayerVirtualLanPriorityCodePoint()+","+
                    sf.getInputPort()+","+
                    sf.getNetworkDestination()+","+
                    sf.getNetworkProtocol()+","+
                    sf.getNetworkSource()+","+
                    sf.getNetworkTypeOfService()+","+
                    sf.getTransportDestination()+","+
                    sf.getTransportSource()+","+
                    sf.getWildcards()+
                    ");";
        //log.debug("sql={}",sql);
        stmt.executeUpdate(sql);
    }
}
