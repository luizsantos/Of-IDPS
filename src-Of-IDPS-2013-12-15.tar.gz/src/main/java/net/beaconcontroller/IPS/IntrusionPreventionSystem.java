package net.beaconcontroller.IPS;

import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;


import net.beaconcontroller.core.IBeaconProvider;
import net.beaconcontroller.core.IOFMessageListener;
import net.beaconcontroller.core.IOFSwitch;
import net.beaconcontroller.tutorial.AnalysisFlow;
import net.beaconcontroller.tutorial.LearningSwitchTutorialSolution;
import net.beaconcontroller.uteis.Arquivo;
import net.beaconcontroller.uteis.ProtocolsNumbers;

import org.openflow.protocol.OFMatch;
import org.openflow.protocol.OFMessage;
import org.openflow.protocol.OFPacketIn;
import org.openflow.protocol.OFType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class IntrusionPreventionSystem extends Thread implements IOFMessageListener{
    
    protected IBeaconProvider beaconProvider;
        
    // TODO ver se o vector � o melhor em desempenho ou se usamos um ArrayList
    List<MensagemAlerta> mensagensAlertas = new java.util.Vector<MensagemAlerta>();
    
    protected static Logger log = LoggerFactory
            .getLogger(LearningSwitchTutorialSolution.class);
    
    public void run() {
        log.debug("Inicia Thread de busca de alertas em IDS");
        while(true) {
            obterAlertasDosIDSs();
            
        }
        
    }
    
    public void startUp(IBeaconProvider bP) {
        log.debug("Inicia alertas em IDS");
        this.beaconProvider = bP;
        beaconProvider.addOFMessageListener(OFType.STATS_REPLY, this);
    }

    public int verificaFluxo(OFPacketIn pi) {
        
        
        OFMatch pacoteEntrando = OFMatch.load(pi.getPacketData(), pi.getInPort());
        
        //mensagensAlertas = obterAlertasDosIDSs();
        
        
        for(MensagemAlerta m : mensagensAlertas) {
            
            int combina=0; // 0 se o pacote n�o combina com as regras, maior que zero se combinar com algum.
            //mostraMensagemAlertaEPacoteDeEntrada(pacoteEntrando, m);
            if(m.getNetworkSource()==pacoteEntrando.getNetworkSource()) combina++;
            if(m.getNetworkDestination()==pacoteEntrando.getNetworkDestination()) combina++;
            if(m.getNetworkProtocol()==pacoteEntrando.getNetworkProtocol()) combina++;
            
            // Se pacote for ICMP n�o verifica portas
            if (m.getNetworkProtocol() == ProtocolsNumbers.ICMP) {
                // TODO - ver o que vai compara com o ICMP, por enquanto s�
                // estou vendo se � ICMP!
                //log.debug("combina={}", combina);
                if (combina >= 3) {
                    //mostraMensagemAlertaEPacoteDeEntrada(pacoteEntrando, m);
                    return m.getPriorityAlert();
                    //return 1; // para bloquear qualquer pacotes que seja fruto de alerta
                }
            }
            
            // Verifica combina��o das portas e o pacote for TCP ou UDP
            if (m.getNetworkProtocol() == ProtocolsNumbers.TCP
                    || m.getNetworkProtocol() == ProtocolsNumbers.UDP) {

                if (m.getTransportSource() == pacoteEntrando.getTransportSource()
                        || m.getTransportDestination() == pacoteEntrando.getTransportDestination())
                    combina++;
                //log.debug("combina={}", combina);
                if (combina >= 4) {
                    //mostraMensagemAlertaEPacoteDeEntrada(pacoteEntrando, m);
                    return m.getPriorityAlert();
                    //return 1; // para bloquear qualquer pacotes que seja fruto de alerta
                }
            }
        }
        return MensagemAlerta.PACOTE_NORMAL;
    }



    
    /**
     * Obtem os alertas de seguran�a de um arquivo no formato:
     * 
     * tempo,priorityAlert,alertDescription,networkSource,networkDestination,networkProtocol,transportSource,transportDestination
     * 1,3,alerta1,167772162,167772161,6,0,666
     * 2,2,alerta2,167772162,167772161,6,0,777
     * 3,1,alerta3,167772162,167772161,6,0,888
     * 
     * nesse � s�o tr�s mensagens entre os computadores 10.0.0.2-> 10.0.0.1 
     * respectivamente nas portas de destino 666,777,888 originadas da porta 0
     * e com prioridades baixa,m�dia,alta.
     * 
     * 
     */
    //public List<MensagemAlerta> obterAlertasDosIDSs() {
    public void obterAlertasDosIDSs() {
        //List<MensagemAlerta> mensagensAlertas = new ArrayList<MensagemAlerta>();

        String diretorioArquivos = "/mnt/armazem/openflow/tmp/dadosSwitchesOF/";
        //String diretorioArquivos = "/mnt/armazem/openflow/tmp/dadosSwitchesOF/alertasTratados/";
        //String nomeArquivo = "alertas";
        String nomeArquivo = "formatted_log.csv";
        
        Arquivo arquivo = new Arquivo(diretorioArquivos, nomeArquivo);
        String hash="";

        while (true) {
            if (!hash.equals(arquivo.hashAquivo())) { // se o conte�do do arquivo mudar! fa�a
                log.debug("Obtendo alertas arquivo {} com hash {}", nomeArquivo, arquivo.hashAquivo());
                mensagensAlertas.clear();
                hash=arquivo.hashAquivo();
                String texto = arquivo.lerArquivo();
                // log.debug("conte�do arquivo: {} ", texto);
                Scanner scanner = new Scanner(texto);
                scanner.useDelimiter("\n");
                // ignora a primeira linha
                //scanner.nextLine();
                while (scanner.hasNextLine()) {
                    String sLine = scanner.nextLine();
                    String[] campos = sLine.split(",");
                    MensagemAlerta msgAlerta = new MensagemAlerta();
                    // TODO Habilitar tempo, tem que converter o formato
                    //msgAlerta.setTempo(Long.valueOf(campos[0]));
                    msgAlerta.setPriorityAlert(Integer.valueOf(campos[1]));
                    msgAlerta.setAlertDescription(campos[2]);
                    //msgAlerta.setNetworkSource(Integer.valueOf(campos[3])); // formato inteiro
                    msgAlerta.setNetworkSource(campos[3]);
                    //msgAlerta.setNetworkDestination(Integer.valueOf(campos[4])); // formato inteiro
                    msgAlerta.setNetworkDestination(campos[4]);
                    int proto=-1;
                    if(campos[5].equals("TCP")) proto = ProtocolsNumbers.TCP; 
                    else if(campos[5].equals("UDP")) proto = ProtocolsNumbers.UDP;
                    else if(campos[5].equals("ICMP")) proto = ProtocolsNumbers.ICMP;
                    msgAlerta.setNetworkProtocol(proto);
                    msgAlerta.setTransportSource(Integer.valueOf(campos[6]));
                    msgAlerta.setTransportDestination(Integer
                            .valueOf(campos[7]));
                    mensagensAlertas.add(msgAlerta);
                }

                AnalysisFlow ana = new AnalysisFlow();
                ana.startUp(beaconProvider);
                // TODO retirar esse tempo depois e voltar o de baixo para 5
                //esperaTempo(2);
                //ana.apagarTodosFluxosTodosSwitches();
                ana.apagarFluxosRelacionadosComMensagensDeAlertasEmTodosSwitches(mensagensAlertas);
                ana.shutDown();
            }
            //esperaTempo(5); // teste anteriores
            esperaTempo(1);
        }
        
        //return mensagensAlertas;
    }
    
    private long getDataAtualMilisegundos() {
        return new Date().getTime();
    }
    
    /**
     * @param tempoSegundos
     *            tempo que o programa ficara aguardando em segundos
     */
    private void esperaTempo(int tempoSegundos) {
        try {
            sleep(tempoSegundos * 1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    /**
     * @param pacoteEntrando -  Pacote que esta entrando pelo switch para descidir se ser� ou criado um fluxo para ele.
     * @param m - Mensagem de alerta gerado pelos IDS.
     * 
     * Mostra o mensagem de alerta e pacote que ser� comparado com esse alerta.
     * 
     */
    private void mostraMensagemAlertaEPacoteDeEntrada(OFMatch pacoteEntrando,
            MensagemAlerta m) {
        log.debug("Alerta-"+
                "IPsrc={}:" +
                "portSrc={} ->\t" +
                "IPdst={}:" +
                "portDst={} " +
                "(proto={})" +
                "\tprioridade={}",
                m.getNetworkSource(),
                m.getTransportSource(),
                m.getNetworkDestination(),
                m.getTransportDestination(),
                m.getNetworkProtocol(),
                m.getPriorityAlert()
                );
        log.debug("Pacote-" +
                "IPsrc={}:" +
                "portSrc={} ->\t" +
                "IPdst={}:" +
                "portDst={} " +
                "(proto={})",
                pacoteEntrando.getNetworkSource(),
                pacoteEntrando.getTransportSource(),
                pacoteEntrando.getNetworkDestination(),
                pacoteEntrando.getTransportDestination(),
                pacoteEntrando.getNetworkProtocol()
                );

    }

    @Override
    public Command receive(IOFSwitch sw, OFMessage msg) throws IOException {
        // TODO Auto-generated method stub
        return null;
    }


}
