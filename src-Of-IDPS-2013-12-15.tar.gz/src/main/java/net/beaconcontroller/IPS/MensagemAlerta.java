package net.beaconcontroller.IPS;

import net.beaconcontroller.packet.IPv4;

/**
 * 
 * @author luiz
 * 
 *         Representa mensagens de alerta, ser� utilizado para ler e/ou gravar
 *         alertas e para comparar os alertas existentes para ver se uma pacote
 *         de rede deve ser bloqueado, alterado a sua prioridade ou liberado.
 * 
 */

public class MensagemAlerta {
    private long tempo; // hor�rio/data do alerta
    private int priorityAlert; // n�vel de prioridade do alerta - Alto, baixo,
                               // m�dio
    private String alertDescription; // descri��o do alerta - caso tenha!
    private int networkDestination; // endere�o IP de destino
    private int networkSource; // endere�o IP de origem
    private int networkProtocol; // protocolo - campo do datagrama IP -
                                 // normalmente TCP, UDP ou ICMP
    private int transportDestination; // porta de destino
    private int transportSource; // porta de origem

    public static final int ALERTA_PRIORIDADE_BAIXA = 3; // Niveis de prioridade
                                                  // segundo snort
    public static final int ALERTA_PRIORIDADE_MEDIA = 2;
    public static final int ALERTA_PRIORIDADE_ALTA = 1;
    public static final int PACOTE_NORMAL = 4;

    public long getTempo() {
        return tempo;
    }

    public void setTempo(long tempo) {
        this.tempo = tempo;
    }

    public int getPriorityAlert() {
        return priorityAlert;
    }

    public void setPriorityAlert(int priorityAlert) {
        this.priorityAlert = priorityAlert;
    }

    public String getAlertDescription() {
        return alertDescription;
    }

    public void setAlertDescription(String alertDescription) {
        this.alertDescription = alertDescription;
    }

    public int getNetworkDestination() {
        return networkDestination;
    }

    public void setNetworkDestination(int networkDestination) {
        this.networkDestination = networkDestination;
    }
    
    public void setNetworkDestination(String networkDestination) {
        try {
         // tratar provis�riamente IPv6
        this.networkDestination = IPv4.toIPv4Address(networkDestination);
        } catch (Exception e) {
            this.networkDestination = IPv4.toIPv4Address("6.6.6.6");
        }
    }

    public int getNetworkSource() {
        return networkSource;
    }

    public void setNetworkSource(int networkSource) {
        this.networkSource = networkSource;
    }
    
    public void setNetworkSource(String networkSource) {
        try {
        this.networkSource = IPv4.toIPv4Address(networkSource);
        } catch (Exception e) {
            // tratar provis�riamente IPv6
            this.networkSource = IPv4.toIPv4Address("6.6.6.6");
        }
    }

    public int getNetworkProtocol() {
        return networkProtocol;
    }

    public void setNetworkProtocol(int networkProtocol) {
        this.networkProtocol = networkProtocol;
    }

    public int getTransportDestination() {
        return transportDestination;
    }

    public void setTransportDestination(int transportDestination) {
        this.transportDestination = transportDestination;
    }

    public int getTransportSource() {
        return transportSource;
    }

    public void setTransportSource(int transportSource) {
        this.transportSource = transportSource;
    }

}
