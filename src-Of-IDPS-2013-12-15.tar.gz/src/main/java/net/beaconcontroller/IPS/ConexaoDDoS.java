package net.beaconcontroller.IPS;

public class ConexaoDDoS extends MensagemAlerta {
    int numeroConexoesSuspeitasDDos;

    public int getNumeroConexoesSuspeitasDDos() {
        return numeroConexoesSuspeitasDDos;
    }

    public void setNumeroConexoesSuspeitasDDos(int numeroConexoesSuspeitasDDos) {
        this.numeroConexoesSuspeitasDDos = numeroConexoesSuspeitasDDos;
    }

}
