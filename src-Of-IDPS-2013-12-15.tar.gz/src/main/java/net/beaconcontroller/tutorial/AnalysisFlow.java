package net.beaconcontroller.tutorial;

import java.io.BufferedWriter;
import java.sql.*;
import org.sqlite.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import net.beaconcontroller.DAO.StatusFlow;
import net.beaconcontroller.DAO.StatusFlowDAO;
import net.beaconcontroller.DAO.StatusPorta;
import net.beaconcontroller.DAO.StatusPortaDAO;
import net.beaconcontroller.IPS.ConexaoDDoS;
import net.beaconcontroller.IPS.MensagemAlerta;
import net.beaconcontroller.core.IBeaconProvider;
import net.beaconcontroller.core.IOFMessageListener;
import net.beaconcontroller.core.IOFSwitch;
import net.beaconcontroller.packet.IPv4;
import net.beaconcontroller.uteis.Arquivo;
import net.beaconcontroller.uteis.ProtocolsNumbers;

import org.openflow.protocol.OFFlowMod;
import org.openflow.protocol.OFMatch;
import org.openflow.protocol.OFMessage;
import org.openflow.protocol.OFPort;
import org.openflow.protocol.OFStatisticsReply;
import org.openflow.protocol.OFStatisticsRequest;
import org.openflow.protocol.OFType;
import org.openflow.protocol.action.OFActionOutput;
import org.openflow.protocol.statistics.OFFlowStatisticsReply;
import org.openflow.protocol.statistics.OFFlowStatisticsRequest;
import org.openflow.protocol.statistics.OFPortStatisticsReply;
import org.openflow.protocol.statistics.OFPortStatisticsRequest;
import org.openflow.protocol.statistics.OFStatistics;
import org.openflow.protocol.statistics.OFStatisticsType;
import org.openflow.protocol.statistics.OFTableStatistics;
import org.openflow.util.HexString;
import org.openflow.util.U16;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class AnalysisFlow extends Thread implements IOFMessageListener {

    protected String diretorioArquivos = "/mnt/armazem/openflow/tmp/dadosSwitchesOF/";
    protected String nomeArquivo = "PortStats";
    protected String nomeDB = "teste.db";

    protected IBeaconProvider beaconProvider;

    protected static Logger log = LoggerFactory
            .getLogger(LearningSwitchTutorialSolution.class);
    
    // TODO ver se o vector � o melhor em desempenho ou se usamos um ArrayList
    //List<MensagemAlerta> conexoesDDoS = new java.util.Vector<MensagemAlerta>();
    HashMap<Integer, ConexaoDDoS> cDDoS =  new HashMap<Integer, ConexaoDDoS>();
    
    public HashMap<Integer, ConexaoDDoS> getcDDoS() {
        return cDDoS;
    }


    public void setcDDoS(HashMap<Integer, ConexaoDDoS> cDDoS) {
        this.cDDoS = cDDoS;
    }


    /**
     * 
     * @param bP - beaconProvider
     * 
     * Inicia a classe;
     * 
     */
    public void startUp(IBeaconProvider bP) {
        this.beaconProvider = bP;
        beaconProvider.addOFMessageListener(OFType.STATS_REPLY, this);
        
        //beaconProvider.addOFMessageListener(OFType.PACKET_IN, this);
        // this.start();
        //log.trace("Starting AnalysisFlow");
    }
        
    
    /**
     * Desliga classe
     * 
     */
    public void shutDown() {
       // log.trace("Stopping AnalysisFlow");
        beaconProvider.removeOFMessageListener(OFType.STATS_REPLY, this);
    }

    /**
     * trata mensagens redebidas dos Swithes
     */
    @Override
    public Command receive(IOFSwitch sw, OFMessage msg) throws IOException {
        if (msg instanceof OFStatisticsReply) {
            //log.debug("Recebendo mensagem de statisticas do sistema");
            OFStatisticsReply reply = (OFStatisticsReply) msg;

            List<OFStatistics> stats = new ArrayList<OFStatistics>();
            stats = reply.getStatistics();

            // log.debug("------Classe stat={}",
            // stats.get(MIN_PRIORITY).getClass());
            if (stats.size() > 0) {
                //verifica se a msg � de statisticas de fluxo
                if (stats.get(0) instanceof OFFlowStatisticsReply) {
                     log.debug("Recebendo mensagem de FLUXO");
                    //printFlowStats(sw, stats);
                    //TODO - ver como gravar no BD acho que vai ter que colocar na thread por que esta dando timeout no switch!
                    //gravarStatusFlowsBD(sw, stats);
                    bloquearDDoS(sw, stats); 
                     
                     
                     
                }
                //verifica se a msg � de statisticas de porta
                if (stats.get(0) instanceof OFPortStatisticsReply) {
                    log.debug(" DESABILITADO - Recebendo mensagem OF de estat�sticas de Porta");
                    //printPortStats(sw, stats);
                    //TODO - ver como gravar no BD acho que vai ter que colocar na thread por que esta dando timeout no switch!
                    //gravarStatusPortsBD(sw, stats);
                }
                // ver se tem mais status
            }
        }        
        return null;
    }

    /*
     * @Override public String getName() { // TODO Auto-generated method stub
     * return "AnalysisFlow"; }
     */

    /**
     * @param sw
     *            switch
     * @param stats
     *            mensagem de status
     * 
     */
    private void printPortStats(IOFSwitch sw, List<OFStatistics> stats) {
        for (int i = 0; i < stats.size(); i++) {
            OFPortStatisticsReply portReply = (OFPortStatisticsReply) stats
                    .get(i);
            // log.debug(
            // "Description Statistics Reply from {} / port {}: env {}/recv {}",
            // sw.getId(), portReply.getPortNumber(),
            // portReply.getTransmitBytes(), portReply.getReceiveBytes());

            String texto = getDataAtualMilisegundos() + "\t" + sw.getId()
                    + "\t" + portReply.getPortNumber() + "\t"
                    + portReply.getTransmitBytes() + "\t"
                    + portReply.getReceiveBytes();
            
            //gravarArquivo(diretorioArquivos + nomeArquivo, texto);
            Arquivo arquivo = new Arquivo(diretorioArquivos, nomeArquivo);
            arquivo.gravarArquivo(texto);

            // printPortsStatisticsDAO();
        }
    }

    /**
     * @param sw
     *            switch
     * @param stats
     *            lista com a mensagem de status openflow de porta
     * 
     *            grava os dados das statisticas de porta no banco de dados
     * 
     */
    private void gravarStatusPortsBD(IOFSwitch sw, List<OFStatistics> stats) {
        if (stats.get(0) instanceof OFPortStatisticsReply) {
            for (int i = 0; i < stats.size(); i++) {
                OFPortStatisticsReply portReply = (OFPortStatisticsReply) stats
                        .get(i);
                try {

                    StatusPorta statusPorta = new StatusPorta();
                    statusPorta.setTodosCamposDeStatisticas(sw.getId(),
                            getDataAtualMilisegundos(), portReply);
                    StatusPortaDAO statusPortaDAO = new StatusPortaDAO(
                            diretorioArquivos + nomeDB);
                    statusPortaDAO.insert(statusPorta);
                    statusPortaDAO.close();
                } catch (ClassNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * @param sw
     *            switch
     * @param stats
     *            lista com a mensagem de status openflow de porta
     * 
     *            grava os dados das statisticas de porta no banco de dados
     * 
     */
    private void gravarStatusFlowsBD(IOFSwitch sw, List<OFStatistics> stats) {
        if (stats.get(0) instanceof OFFlowStatisticsReply) {
            for (int i = 0; i < stats.size(); i++) {
                OFFlowStatisticsReply flowReply = (OFFlowStatisticsReply) stats
                        .get(i);

                try {

                    StatusFlow statusFlow = new StatusFlow();
                    statusFlow.setTodosCamposDeStatisticas(sw.getId(),
                            getDataAtualMilisegundos(), flowReply);
                    StatusFlowDAO statusFlowDao = new StatusFlowDAO(
                            diretorioArquivos + nomeDB);
                    statusFlowDao.insert(statusFlow);
                    statusFlowDao.close();
                } catch (ClassNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * imprime as statisticas das portas dos switches extraidas do banco de
     * dados
     */
    private void printPortsStatisticsDAO() {
        Vector<StatusPorta> vetorStatusPorta = new Vector<StatusPorta>();
        StatusPortaDAO sPDao;
        try {
            sPDao = new StatusPortaDAO(diretorioArquivos + nomeDB);
            vetorStatusPorta = sPDao.getAll();
            for (StatusPorta sP : vetorStatusPorta) {
                log.debug(
                        "Sw={}, PortNumber={}, BytesRx={}, PacketsRx={}, BytesTx={}, PacketsTx={}",
                        sP.getSwID(), sP.getPortNumber(), sP.getReceiveBytes(),
                        sP.getreceivePackets(), sP.getTransmitBytes(),
                        sP.getTransmitPackets());
            }
        } catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    /**
     * @return retorna data atual do sistema
     */
    private long getDataAtualMilisegundos() {
        // Calendar cal = new GregorianCalendar();
        // Date date = new Date();
        // cal.setTime(date);
        // return cal.getTimeInMillis();
        return new Date().getTime();
    }

    /**
     * @param nomeArquivo
     *            Nome do Arquivo a ser gravado
     * @param texto
     *            Conte�do a ser gravado
     */
//    private void gravarArquivo(String nomeArquivo, String texto) {
//        try {
//
//            FileWriter fstream = new FileWriter(nomeArquivo, true);
//            BufferedWriter out = new BufferedWriter(fstream);
//            out.write(texto);
//            out.write("\n");
//            out.close();
//        } catch (IOException e) { // TODO Auto-generated catch block
//            e.printStackTrace();
//            log.debug("Aten��o! n�o foi poss�vel gravar o arquivo: {}",
//                    nomeArquivo);
//        }
//    }

    /**
     * @param sw - Switch
     * @param stats - Stat�ticas
     * 
     * imprimir statisticas de fluxos
     * 
     */
    private void printFlowStats(IOFSwitch sw, List<OFStatistics> stats) {
        for (int i = 0; i < stats.size(); i++) {
            OFFlowStatisticsReply flowReply = (OFFlowStatisticsReply) stats
                    .get(i);
            /*
             * log.debug(
             * "Description Statistics Reply from tableId {} / packetCount {}: env {}/duration {}"
             * , sw.getId(), flowReply.getTableId(), flowReply.getPacketCount(),
             * flowReply.getDurationSeconds());
             */

            OFMatch match = new OFMatch();
            match = flowReply.getMatch();

            log.debug(
                    "in port: {}, HwSrc: {}, HwDst: {}, IPSrc:{}:{}, IPDst:{}:{}, Proto:{}, bytes:{}, packets:{}",
                    match.getInputPort(),
                    HexString.toHexString(match.getDataLayerSource()),
                    HexString.toHexString(match.getDataLayerDestination()),
                    IPv4.fromIPv4Address(match.getNetworkSource()),
                    match.getTransportSource(),
                    IPv4.fromIPv4Address(match.getNetworkDestination()),
                    match.getTransportDestination(),
                    match.getNetworkProtocol(), flowReply.getByteCount(),
                    flowReply.getPacketCount());

            /*
             * log.debug("\t{}:{} -> {}:{} - proto: {}",
             * IPv4.fromIPv4Address(match.getNetworkSource()),
             * match.getTransportSource(),
             * IPv4.fromIPv4Address(match.getNetworkDestination()),
             * match.getTransportDestination(), match.getNetworkProtocol());
             */

        }
    }
    
    /**
     * @param sw - Switch
     * @param stats - Stat�ticas
     * 
     * imprimir statisticas de fluxos
     * 
     */
    public void bloquearDDoS(IOFSwitch sw, List<OFStatistics> stats) {
        //IPOrigem, conexao
        HashMap<Integer, ConexaoDDoS> conexao = new HashMap<Integer, ConexaoDDoS>();
               
            for (int i = 0; i < stats.size(); i++) {
                OFFlowStatisticsReply flowReply = (OFFlowStatisticsReply) stats
                        .get(i);

                OFMatch match = new OFMatch();
                match = flowReply.getMatch();

                if (conexao.containsKey(match.getNetworkSource())) {
                    ConexaoDDoS conDDoS = new ConexaoDDoS();
                    conDDoS = conexao.get(match.getNetworkSource());
                    if (flowReply.getPacketCount() <= 5
                            && match.getTransportDestination() <= 1024) {
                        int nConexaoDDoS = conDDoS
                                .getNumeroConexoesSuspeitasDDos() + 1;
                        conDDoS.setNumeroConexoesSuspeitasDDos(nConexaoDDoS);
                        conexao.put(match.getNetworkSource(), conDDoS);
                    }
                    // TODO - qual n�mero usar para saber se j� � DDoS? 100?
                    if (conDDoS.getNumeroConexoesSuspeitasDDos() > 20) {
                        conDDoS.setNetworkSource(match.getNetworkSource());
                        conDDoS.setNetworkDestination(match.getNetworkDestination());
                        conDDoS.setNetworkProtocol(match.getNetworkProtocol());
                        conDDoS.setTransportSource(match.getTransportSource());
                        conDDoS.setTransportDestination(match.getTransportDestination());
                        conDDoS.setPriorityAlert(3);
                        if (conDDoS.getNumeroConexoesSuspeitasDDos() > 50) {
                            conDDoS.setPriorityAlert(2);
                            if (conDDoS.getNumeroConexoesSuspeitasDDos() > 100)
                                conDDoS.setPriorityAlert(1);
                        }
                        
                        cDDoS.put(match.getNetworkSource(), conDDoS);
                    }

                    // teste se maior que 10 se for retira!
                } else {
                    ConexaoDDoS conDDoS = new ConexaoDDoS();
                    conDDoS.setNumeroConexoesSuspeitasDDos(1);
                    conexao.put(match.getNetworkSource(), conDDoS);
                }

                /*
                 * log.debug("\t{}:{} -> {}:{} - proto: {}",
                 * IPv4.fromIPv4Address(match.getNetworkSource()),
                 * match.getTransportSource(),
                 * IPv4.fromIPv4Address(match.getNetworkDestination()),
                 * match.getTransportDestination(), match.getNetworkProtocol());
                 */

            }

            for (Integer e : conexao.keySet()) {
                ConexaoDDoS nCx = conexao.get(e);
                log.debug("IPOrigem= {}, n�mero de conex�es = {}", e,
                        nCx.getNumeroConexoesSuspeitasDDos());
            }                
    }
    
    
    /**
     * @param sw
     * 
     * Deletar todos os fluxos de um Switch
     * 
     */
    public void deleteAllFlowMod(IOFSwitch sw) {
        OFMatch match = new OFMatch().setWildcards(OFMatch.OFPFW_ALL);
        OFMessage fm = ((OFFlowMod) sw.getInputStream().getMessageFactory()

            .getMessage(OFType.FLOW_MOD))

            .setMatch(match)

            .setCommand(OFFlowMod.OFPFC_DELETE)

            .setOutPort(OFPort.OFPP_NONE)

            .setLength(U16.t(OFFlowMod.MINIMUM_LENGTH));

        try {
            sw.getOutputStream().write(fm);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            log.debug("Imposs�vel deletar fluxo");
            e.printStackTrace();
        }

    }
    
    
    /**
     * @param sw
     * 
     * Deletar os fluxos de um Switch - TESTE
     * 
     */
//    private void deleteFlowMod(IOFSwitch sw) {
//        OFMatch match = new OFMatch();
//        match.setNetworkProtocol((byte)0x01);
//        match.setNetworkDestination(167772161);
//        match.setWildcards(OFMatch.OFPFW_ALL ^ (OFMatch.OFPFW_NW_PROTO | OFMatch.OFPFW_NW_DST_MASK));
//        
//        OFMessage fm = ((OFFlowMod) sw.getInputStream().getMessageFactory()
//
//            .getMessage(OFType.FLOW_MOD))
//
//            .setMatch(match)
//
//            .setCommand(OFFlowMod.OFPFC_DELETE)
//
//            .setOutPort(OFPort.OFPP_NONE)
//
//            .setLength(U16.t(OFFlowMod.MINIMUM_LENGTH));
//
//        try {
//            sw.getOutputStream().write(fm);
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            log.debug("Imposs�vel deletar fluxo");
//            e.printStackTrace();
//        }
//
//    }
    

    /**
     * @param sw - Switch a ser obtido estat�sticas de portas
     */
    private void getPortStatistics(IOFSwitch sw) {
        OFStatisticsRequest req = new OFStatisticsRequest();
        OFPortStatisticsRequest psr = new OFPortStatisticsRequest();
        psr.setPortNumber(OFPort.OFPP_NONE.getValue());
        req.setStatisticType(OFStatisticsType.PORT);
        req.setStatistics(psr);
        req.setLengthU(req.getLengthU() + psr.getLength());

        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * @param sw - Switch a ser obtido estat�sticas de tabelas
     */
    private void getTableStatistics(IOFSwitch sw) {
        OFStatisticsRequest req = new OFStatisticsRequest();
        req.setStatisticType(OFStatisticsType.TABLE);
        req.setLengthU(req.getLengthU());
        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    /**
     * @param sw - Switch a ser obtido estat�sticas de fila
     */
    private void getQueueStatistics(IOFSwitch sw) {
        
        // tem que terminar de implementar!
        
        OFStatisticsRequest req = new OFStatisticsRequest();
        req.setStatisticType(OFStatisticsType.QUEUE);
        req.setLengthU(req.getLengthU());
        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param sw - Switch a ser obtido estat�sticas de fluxo
     */
    private void getFlowStatistics(IOFSwitch sw) {

        OFStatisticsRequest req = new OFStatisticsRequest();
        OFFlowStatisticsRequest ofFlowRequest = new OFFlowStatisticsRequest();

        OFMatch match = new OFMatch();
        match.setWildcards(0xffffffff);

        ofFlowRequest.setMatch(match);
        ofFlowRequest.setOutPort(OFPort.OFPP_NONE.getValue());
        ofFlowRequest.setTableId((byte) 0xff);

        req.setStatisticType(OFStatisticsType.FLOW);
        req.setStatistics(ofFlowRequest);
        req.setLengthU(req.getLengthU() + ofFlowRequest.getLength());

        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 
     * Inicia a thread de analise de fluxo para pegar as statisticas dos switches a rede
     * 
     */
    public void run() {
        log.debug("Envia mensagens de pedido de status");
        int numeroSwitches=0;
        while (true) {
            // intervalo de tempo que o sistema ira fazer a requisi��o de status
            // dos switchs
            int tempoSegundos = 3;
            esperaTempo(tempoSegundos);
            if (beaconProvider.getListeningIPAddress().isAnyLocalAddress()) {
                /*
                 * log.debug("IP do Switch: {} - porta {}",
                 * IPv4.fromIPv4Address(
                 * beaconProvider.getListeningIPAddress().getAddress()),
                 * beaconProvider.getListeningPort());
                 */
                // mostra os switches que est�o na rede!
                // log.debug("switches={}", beaconProvider.getSwitches());
                

//                Map<String, Object> model = new HashMap<String, Object>();
//                model.put("switches", beaconProvider.getSwitches().values());

                // TODO ERRO -  a vezes aparecem sw que nao estao na lista! acho que as linhas abaixo corrigiram o problema 

                Collection<IOFSwitch> col = new HashSet<IOFSwitch>();
                //Collection<IOFSwitch> col = beaconProvider.getSwitches().values();
                col.clear();
                col = beaconProvider.getSwitches().values();
                for (IOFSwitch s : col) {
                    if (numeroSwitches != col.size()) { // mostra os switches
                                                        // presentes na rede
                                                        // apenas se mudar o
                                                        // n�mero de switches
                        log.debug(
                                ">>>>>>Switches conectados: switchId={} - enviando pedido de mesagens de statisticas!",
                                s.getId());
                    }
                    IOFSwitch sw = beaconProvider.getSwitches().get(s.getId());
                    
                    // TODO  - comentando essas linhas para testar flowMod descomentar as tres linhas abaixo
                    getFlowStatistics(sw);
                    esperaTempo(tempoSegundos);
                    getPortStatistics(sw);
                    esperaTempo(tempoSegundos);

                    // falta fazer o m�todo que grava a TableStatistics no DB
                    // esperaTempo(1);
                    // getTableStatistics(sw);
                    // getQueueStatistics(sw);
                    
                    
                    // teste
                    //deleteAllFlowMod(s);
                    //deleteFlowMod(s);
                    // fim teste

                    
                }
                numeroSwitches = col.size();
            } else {
                log.debug("Aten��o - N�o existem Switches dispon�veis na rede - imposs�vel obter status");
            }
        }

    }
    
    

    /**
     * @param tempoSegundos
     *            tempo que o programa ficara aguardando em segundos
     */
    private void esperaTempo(int tempoSegundos) {
        try {
            sleep(tempoSegundos * 1000);
        } catch (InterruptedException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
    
    /**
     * Obtem uma lista com os todos os Switches presentes na rede!
     * 
     * @return Cole��o de switches presentes na rede
     */
    private Collection<IOFSwitch> obterSwitchesNaRede() {
        //log.debug("Obter switches na rede");
        if (beaconProvider.getListeningIPAddress().isAnyLocalAddress()) {
            // TODO ERRO - a vezes aparecem sw que nao estao na lista! acho que
            // as linhas abaixo corrigiram o problema
            Collection<IOFSwitch> col = new HashSet<IOFSwitch>();
            col.clear();
            col = beaconProvider.getSwitches().values();
            return col;
        } else {
            log.debug("Aten��o - N�o existem Switches dispon�veis na rede");
        }
        return null;
    }
    
    /**
     * Apaga TODOS os fluxos de TODOS os switches! Se a ideia � apagar somente
     * alertas isso pode ser ruim, por que n�o apaga somente alertas...
     */
    public void apagarTodosFluxosTodosSwitches() {
        log.debug("Apagar todos Fluxos de Todos os Switches");
        Collection<IOFSwitch> switches = new HashSet<IOFSwitch>();
        switches = obterSwitchesNaRede();
        for(IOFSwitch s : switches) {
            IOFSwitch sw = beaconProvider.getSwitches().get(s.getId());
            deleteAllFlowMod(sw);
        }
    }
    
    
    /**
     * @param - Lista com as mensagens de alertas (classe MensagemAlerta)
     * 
     * Apaga fluxos relacionados com as mensagens de alertas em TODOS os switches
     */
    public void apagarFluxosRelacionadosComMensagensDeAlertasEmTodosSwitches(List<MensagemAlerta> mensagensAlertas) {
        log.debug("Apagar fluxos de ALERTAS em todos os Switches");
        Collection<IOFSwitch> switches = new HashSet<IOFSwitch>();
        switches = obterSwitchesNaRede();
        for (MensagemAlerta msg : mensagensAlertas) {
            for (IOFSwitch s : switches) {
                IOFSwitch sw = beaconProvider.getSwitches().get(s.getId());
                // deleteAllFlowMod(sw);

                // TESTE

                OFMatch match = new OFMatch();
                if (msg.getNetworkProtocol() == ProtocolsNumbers.ICMP) {
                    deletaFluxoIPSrcIPDstProto(msg, sw, match);
                } else { // para fluxos que possuem portas - normalmente TCP e
                         // UDP! Apesar que o ICMP no beacon tbm tem o campo
                         // type colocado como porta, mas por enquanto n�o
                         // estamos utilizando isso!
                    deletaFluxoIPSrcIPDstProtoPortaDst(msg, sw, match);
                    
                }
                // FIM TESTE

            }
        }
    }


    /**
     * @param msg
     * @param sw
     * @param match
     * 
     *            Deleta os fluxos apenas utilizando IPOrigem IPDetino e campo
     *            protocolo. � para bloquear fluxo ICMP, por exemplo, que n�o
     *            tem os campos portas.
     * 
     */
    private void deletaFluxoIPSrcIPDstProto(MensagemAlerta msg, IOFSwitch sw,
            OFMatch match) {
        match.setNetworkSource(msg.getNetworkSource());
        match.setNetworkDestination(msg.getNetworkDestination());
        match.setNetworkProtocol((byte) msg.getNetworkProtocol());
        match.setWildcards(OFMatch.OFPFW_ALL
                ^ (OFMatch.OFPFW_NW_SRC_MASK | OFMatch.OFPFW_NW_DST_MASK | OFMatch.OFPFW_NW_PROTO));

        OFMessage fm = ((OFFlowMod) sw.getInputStream()
                .getMessageFactory()

                .getMessage(OFType.FLOW_MOD))

        .setMatch(match)

        .setCommand(OFFlowMod.OFPFC_DELETE)

        .setOutPort(OFPort.OFPP_NONE)

        .setLength(U16.t(OFFlowMod.MINIMUM_LENGTH));

        try {
            sw.getOutputStream().write(fm);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            log.debug("Imposs�vel deletar fluxo");
            e.printStackTrace();
        }
    }
    
    /**
     * @param msg
     * @param sw
     * @param match
     * 
     *            Deleta os fluxos apenas utilizando IPOrigem IPDetino e campo
     *            protocolo. � para bloquear fluxo ICMP, por exemplo, que n�o
     *            tem os campos portas.
     *            
     *            TODO o bloqueio est� sendo feito apenas pela porta de destino e n�o pela porta de origem, 
     *            isso porque a porta de origem do lado cliente � aleat�ria e pode causar problemas. 
     *            Ver se isso vai ser feito depois!
     *            
     *            - para as conex�es ativas at� daria para pegar as portas de origem e destino, mas ter�amos que
     *            controlar a quest�o do tempo!
     * 
     */
    private void deletaFluxoIPSrcIPDstProtoPortaDst(MensagemAlerta msg, IOFSwitch sw,
            OFMatch match) {
        // match.setNetworkProtocol((byte) 0x01);
        match.setNetworkSource(msg.getNetworkSource());
        match.setNetworkDestination(msg.getNetworkDestination());
        match.setNetworkProtocol((byte) msg.getNetworkProtocol());
        //match.setTransportSource((short) msg.getTransportSource());
        match.setTransportDestination((short) msg.getTransportDestination());
        match.setWildcards(OFMatch.OFPFW_ALL
                ^ (OFMatch.OFPFW_NW_SRC_MASK | OFMatch.OFPFW_NW_DST_MASK | OFMatch.OFPFW_NW_PROTO |
                        OFMatch.OFPFW_TP_DST));

        OFMessage fm = ((OFFlowMod) sw.getInputStream()
                .getMessageFactory()

                .getMessage(OFType.FLOW_MOD))

        .setMatch(match)

        .setCommand(OFFlowMod.OFPFC_DELETE)

        .setOutPort(OFPort.OFPP_NONE)

        .setLength(U16.t(OFFlowMod.MINIMUM_LENGTH));

        try {
            sw.getOutputStream().write(fm);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            log.debug("Imposs�vel deletar fluxo");
            e.printStackTrace();
        }
    }


}
