package net.beaconcontroller.tutorial;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import net.beaconcontroller.core.IBeaconProvider;
import net.beaconcontroller.core.IOFMessageListener;
import net.beaconcontroller.core.IOFSwitch;
import net.beaconcontroller.packet.IPv4;

import org.openflow.protocol.OFMatch;
import org.openflow.protocol.OFMessage;
import org.openflow.protocol.OFPort;
import org.openflow.protocol.OFStatisticsReply;
import org.openflow.protocol.OFStatisticsRequest;
import org.openflow.protocol.statistics.OFFlowStatisticsReply;
import org.openflow.protocol.statistics.OFFlowStatisticsRequest;
import org.openflow.protocol.statistics.OFPortStatisticsReply;
import org.openflow.protocol.statistics.OFPortStatisticsRequest;
import org.openflow.protocol.statistics.OFStatistics;
import org.openflow.protocol.statistics.OFStatisticsType;
import org.openflow.util.HexString;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class EnviaStatusRequest extends Thread implements IOFMessageListener {

    protected IBeaconProvider beaconProvider;

    protected interface OFSRCallback {
        OFStatisticsRequest getRequest();
    }

    protected static Logger log = LoggerFactory
            .getLogger(LearningSwitchTutorialSolution.class);

    public void startUp(IBeaconProvider bP) {
        this.beaconProvider = bP;
        //beaconProvider.addOFMessageListener(OFType.STATS_REPLY, this);
        this.start();
        log.trace("Starting AnalysisFlow");
    }
    
    public void run(IBeaconProvider bP) {
        this.beaconProvider = bP;
        //beaconProvider.addOFMessageListener(OFType.STATS_REPLY, this);
        this.start();
        log.trace("Starting AnalysisFlow");
    }

    public void shutDown() {
        log.trace("Stopping AnalysisFlow");

    }

    public void getSwitchFlowsDataTable(String switchId) {
        List<OFFlowStatisticsReply> data = new ArrayList<OFFlowStatisticsReply>();
        List<OFStatistics> stats = getSwitchFlows(switchId);
        if (stats != null) {
            // Ugly cast.. sigh
            data.addAll((Collection<? extends OFFlowStatisticsReply>) stats);
        }
        log.debug("tablesID:{}", data);

    }

    protected List<OFStatistics> getSwitchStats(OFSRCallback f,
            String switchId, String statsType) {
        IOFSwitch sw = beaconProvider.getSwitches().get(
                HexString.toLong(switchId));
        Future<List<OFStatistics>> future;
        List<OFStatistics> values = null;
        if (sw != null) {
            try {
                future = sw.getStatistics(f.getRequest());
                values = future.get(10, TimeUnit.SECONDS);
            } catch (Exception e) {
                log.error("Failure retrieving " + statsType, e);
            }
        }
        return values;
    }

    protected class makeFlowStatsRequest implements OFSRCallback {
        public OFStatisticsRequest getRequest() {
            OFStatisticsRequest req = new OFStatisticsRequest();
            OFFlowStatisticsRequest fsr = new OFFlowStatisticsRequest();
            OFMatch match = new OFMatch();
            match.setWildcards(0xffffffff);
            fsr.setMatch(match);
            fsr.setOutPort(OFPort.OFPP_NONE.getValue());
            fsr.setTableId((byte) 0xff);
            req.setStatisticType(OFStatisticsType.FLOW);
            req.setStatistics(fsr);
            req.setLengthU(req.getLengthU() + fsr.getLength());
            return req;
        };
    }

    protected List<OFStatistics> getSwitchFlows(String switchId) {
        return getSwitchStats(new makeFlowStatsRequest(), switchId, "flows");
    }

    @Override
    public Command receive(IOFSwitch sw, OFMessage msg) throws IOException {
        if (msg instanceof OFStatisticsReply) {
            log.debug("RECEIVED STATISTIC REPLY !!!");
            OFStatisticsReply reply = (OFStatisticsReply) msg;

            // tem que ver o que vai fazer se for para porta se for para flow
            // etc... aqui s� esta tratando porta

            List<OFStatistics> stats = new ArrayList<OFStatistics>();
            stats = reply.getStatistics();

            // printPortStats(sw, stats);
            printFlowStats(sw, stats);
        }
        return null;
    }

    /*
     * @Override public String getName() { // TODO Auto-generated method stub
     * return "AnalysisFlow"; }
     */

    /**
     * @param sw
     * @param stats
     */
    private void printPortStats(IOFSwitch sw, List<OFStatistics> stats) {
        for (int i = 0; i < stats.size(); i++) {
            OFPortStatisticsReply portReply = (OFPortStatisticsReply) stats
                    .get(i);
            log.debug(
                    "Description Statistics Reply from {} / port {}: env {}/recv {}",
                    sw.getId(), portReply.getPortNumber(),
                    portReply.getTransmitBytes(), portReply.getReceiveBytes());
        }
    }

    /**
     * @param sw
     * @param stats
     */
    private void printFlowStats(IOFSwitch sw, List<OFStatistics> stats) {
        for (int i = 0; i < stats.size(); i++) {
            OFFlowStatisticsReply flowReply = (OFFlowStatisticsReply) stats
                    .get(i);
            /*
             * log.debug(
             * "Description Statistics Reply from tableId {} / packetCount {}: env {}/duration {}"
             * , sw.getId(), flowReply.getTableId(), flowReply.getPacketCount(),
             * flowReply.getDurationSeconds());
             */

            OFMatch match = new OFMatch();
            match = flowReply.getMatch();

            log.debug(
                    "in port: {}, HwSrc: {}, HwDst: {}, IPSrc:{}:{}, IPDst:{}:{}, Proto:{}, bytes:{}, packets:{}",
                    match.getInputPort(),
                    HexString.toHexString(match.getDataLayerSource()),
                    HexString.toHexString(match.getDataLayerDestination()),
                    IPv4.fromIPv4Address(match.getNetworkSource()),
                    match.getTransportSource(),
                    IPv4.fromIPv4Address(match.getNetworkDestination()),
                    match.getTransportDestination(),
                    match.getNetworkProtocol(), flowReply.getByteCount(),
                    flowReply.getPacketCount());

            /*
             * log.debug("\t{}:{} -> {}:{} - proto: {}",
             * IPv4.fromIPv4Address(match.getNetworkSource()),
             * match.getTransportSource(),
             * IPv4.fromIPv4Address(match.getNetworkDestination()),
             * match.getTransportDestination(), match.getNetworkProtocol());
             */

        }
    }

    /**
     * @param sw
     */
    private void getPortStatistics(IOFSwitch sw) {
        OFStatisticsRequest req = new OFStatisticsRequest();
        OFPortStatisticsRequest psr = new OFPortStatisticsRequest();
        psr.setPortNumber(OFPort.OFPP_NONE.getValue());
        req.setStatisticType(OFStatisticsType.PORT);
        req.setStatistics(psr);
        req.setLengthU(req.getLengthU() + psr.getLength());

        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param sw
     */
    private void getFlowStatistics(IOFSwitch sw) {

        OFStatisticsRequest req = new OFStatisticsRequest();
        OFFlowStatisticsRequest ofFlowRequest = new OFFlowStatisticsRequest();

        OFMatch match = new OFMatch();
        match.setWildcards(0xffffffff);

        ofFlowRequest.setMatch(match);
        ofFlowRequest.setOutPort(OFPort.OFPP_NONE.getValue());
        ofFlowRequest.setTableId((byte) 0xff);

        req.setStatisticType(OFStatisticsType.FLOW);
        req.setStatistics(ofFlowRequest);
        req.setLengthU(req.getLengthU() + ofFlowRequest.getLength());

        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 
     */
    public void run() {
        log.debug("Envia mensagens de pedido de status");
        
        while (true) {
            try {
                //faz o envio a cada 5 segundos
                int tempoSegundos=2;
                sleep(tempoSegundos*1000);
            } catch (InterruptedException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            
            if (beaconProvider.getListeningIPAddress().isAnyLocalAddress()) {
                log.debug("IP do Switch: {} - porta {}", beaconProvider.getListeningIPAddress().getHostAddress(), beaconProvider.getListeningPort());
                
                //IOFSwitch sw = beaconProvider.getSwitches().get(HexString.toLong(switchId));
                
                //List<IOFSwitch> switches = new ArrayList<IOFSwitch>();
                //Map<String, IOFSwitch> switches;
                //switches = beaconProvider.getSwitches();
                
                log.debug("switches={}", beaconProvider.getSwitches());
               
                //Map<String, Object> model = new HashMap<String, Object>();
                //model.put("switches", beaconProvider.getSwitches().values());                
                //IOFSwitch s = (IOFSwitch)model.get("switches");               
               //log.debug("Sw={}", s.getId());
                
                Collection<IOFSwitch> col = beaconProvider.getSwitches().values();
                
                for(IOFSwitch s : col) {
                    log.debug("switchId={}",s.getId());
                    //IOFSwitch sw = beaconProvider.getSwitches().get(HexString.toLong("00:00:00:00:00:00:00:01"));
                    IOFSwitch sw = beaconProvider.getSwitches().get(s.getId());
                    //getFlowStatistics(sw);
                    getPortStatistics(sw);
                    
                }
                
                
                
                
            } else {
                log.debug("Aten��o - N�o existem Switches dispon�veis na rede - imposs�vel obter status");
            }
            
            log.debug(".");
            // getFlowStatistics(sw);
        }

    }

}
