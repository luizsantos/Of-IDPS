/**
 * Copyright 2010-2013, Stanford University. This file is licensed under the
 * BSD license as described in the included LICENSE.txt.
 */
package net.beaconcontroller.tutorial;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.security.auth.login.AccountLockedException;

import net.beaconcontroller.IPS.ConexaoDDoS;
import net.beaconcontroller.IPS.IntrusionPreventionSystem;
import net.beaconcontroller.IPS.MensagemAlerta;
import net.beaconcontroller.core.IBeaconProvider;
import net.beaconcontroller.core.IOFMessageListener;
import net.beaconcontroller.core.IOFSwitch;
import net.beaconcontroller.core.IOFSwitchListener;
import net.beaconcontroller.packet.Ethernet;
import net.beaconcontroller.packet.IPv4;

import org.openflow.protocol.OFFlowMod;
import org.openflow.protocol.OFMatch;
import org.openflow.protocol.OFMessage;
import org.openflow.protocol.OFPacketIn;
import org.openflow.protocol.OFPacketOut;
import org.openflow.protocol.OFPort;
import org.openflow.protocol.OFStatisticsRequest;
import org.openflow.protocol.OFType;
import org.openflow.protocol.action.OFAction;
import org.openflow.protocol.action.OFActionEnqueue;
import org.openflow.protocol.action.OFActionOutput;
import org.openflow.protocol.statistics.OFFlowStatisticsReply;
import org.openflow.protocol.statistics.OFFlowStatisticsRequest;
import org.openflow.protocol.statistics.OFPortStatisticsReply;
import org.openflow.protocol.statistics.OFPortStatisticsRequest;
import org.openflow.protocol.statistics.OFStatistics;
import org.openflow.protocol.statistics.OFStatisticsType;
import org.openflow.util.HexString;
import org.openflow.util.U16;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ola Tutorial class used to teach how to build a simple layer 2 learning
 * switch.
 * 
 * @author David Erickson (daviderickson@cs.stanford.edu) - 10/14/12
 */
public class LearningSwitchTutorialSolution implements IOFMessageListener,
        IOFSwitchListener {
    
    AnalysisFlow analysisFlow = new AnalysisFlow();
    
    
    protected IntrusionPreventionSystem ips = new IntrusionPreventionSystem();
    
    protected static Logger log = LoggerFactory
            .getLogger(LearningSwitchTutorialSolution.class);
    protected IBeaconProvider beaconProvider;
    protected Map<IOFSwitch, Map<Long, Short>> macTables = new HashMap<IOFSwitch, Map<Long, Short>>();
    public final int QUEUE_LARGURA_BANDA_ALTA  = 0;
    public final int QUEUE_LARGURA_BANDA_MEDIA = 1;
    public final int QUEUE_LARGURA_BANDA_BAIXA = 2;
    public final int BLOQUEIA = 0;
    
    public Command receive(IOFSwitch sw, OFMessage msg) throws IOException {
        initMACTable(sw);
        if (msg instanceof OFPacketIn) {
            OFPacketIn pi = (OFPacketIn) msg;
            // forwardAsHub(sw, pi);
            forwardAsLearningSwitchWithIPS(sw, pi);
            
        }
        

        return Command.CONTINUE;
    }

    /**
     * @param sw
     * @param stats
     */
    private void printPortStats(IOFSwitch sw, List<OFStatistics> stats) {
        for (int i = 0; i < stats.size(); i++) {
            OFPortStatisticsReply portReply = (OFPortStatisticsReply) stats
                    .get(i);
            log.debug(
                    "Description Statistics Reply from {} / port {}: env {}/recv {}",
                    sw.getId(), portReply.getPortNumber(),
                    portReply.getTransmitBytes(), portReply.getReceiveBytes());
        }
    }

    /**
     * @param sw
     * @param stats
     */
    private void printFlowStats(IOFSwitch sw, List<OFStatistics> stats) {
        for (int i = 0; i < stats.size(); i++) {
            OFFlowStatisticsReply flowReply = (OFFlowStatisticsReply) stats
                    .get(i);
            /*
             * log.debug(
             * "Description Statistics Reply from tableId {} / packetCount {}: env {}/duration {}"
             * , sw.getId(), flowReply.getTableId(), flowReply.getPacketCount(),
             * flowReply.getDurationSeconds());
             */

            OFMatch match = new OFMatch();
            match = flowReply.getMatch();

            log.debug(
                    "in port: {}, HwSrc: {}, HwDst: {}, IPSrc:{}:{}, IPDst:{}:{}, Proto:{}, bytes:{}, packets:{}",
                    match.getInputPort(),
                    HexString.toHexString(match.getDataLayerSource()),
                    HexString.toHexString(match.getDataLayerDestination()),
                    IPv4.fromIPv4Address(match.getNetworkSource()),
                    match.getTransportSource(),
                    IPv4.fromIPv4Address(match.getNetworkDestination()),
                    match.getTransportDestination(),
                    match.getNetworkProtocol(), flowReply.getByteCount(),
                    flowReply.getPacketCount());

            /*
             * log.debug("\t{}:{} -> {}:{} - proto: {}",
             * IPv4.fromIPv4Address(match.getNetworkSource()),
             * match.getTransportSource(),
             * IPv4.fromIPv4Address(match.getNetworkDestination()),
             * match.getTransportDestination(), match.getNetworkProtocol());
             */

        }
    }

    /**
     * @param sw
     */
    private void getPortStatistics(IOFSwitch sw) {
        OFStatisticsRequest req = new OFStatisticsRequest();
        OFPortStatisticsRequest psr = new OFPortStatisticsRequest();
        psr.setPortNumber(OFPort.OFPP_NONE.getValue());
        req.setStatisticType(OFStatisticsType.PORT);
        req.setStatistics(psr);
        req.setLengthU(req.getLengthU() + psr.getLength());

        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * @param sw
     */
    private void getFlowStatistics(IOFSwitch sw) {

        OFStatisticsRequest req = new OFStatisticsRequest();
        OFFlowStatisticsRequest ofFlowRequest = new OFFlowStatisticsRequest();

        OFMatch match = new OFMatch();
        match.setWildcards(0xffffffff);

        ofFlowRequest.setMatch(match);
        ofFlowRequest.setOutPort(OFPort.OFPP_NONE.getValue());
        ofFlowRequest.setTableId((byte) 0xff);

        req.setStatisticType(OFStatisticsType.FLOW);
        req.setStatistics(ofFlowRequest);
        req.setLengthU(req.getLengthU() + ofFlowRequest.getLength());

        try {
            sw.getOutputStream().write(req);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * EXAMPLE CODE: Floods the packet out all switch ports except the port it
     * came in on.
     * 
     * @param sw
     *            the OpenFlow switch object
     * @param pi
     *            the OpenFlow Packet In object
     * @throws IOException
     */
    public void forwardAsHub(IOFSwitch sw, OFPacketIn pi) throws IOException {
        // Create the OFPacketOut OpenFlow object
        OFPacketOut po = new OFPacketOut();

        // Create an output action to flood the packet, put it in the
        // OFPacketOut
        OFAction action = new OFActionOutput(OFPort.OFPP_FLOOD.getValue());
        po.setActions(Collections.singletonList(action));

        // Set the port the packet originally arrived on
        po.setInPort(pi.getInPort());

        OFMatch match = new OFMatch();
        match.loadFromPacket(pi.getPacketData(), (short) 0);
        /*
         * log.info("PortIn {}:", pi.getInPort());
         * log.info("L2  type {}, {}->{}",match.getDataLayerType(),
         * HexString.toHexString
         * (match.getDataLayerSource()),HexString.toHexString
         * (match.getDataLayerDestination()));
         * log.info("L3 proto {}, {}->{}",match
         * .getNetworkProtocol(),IPv4.fromIPv4Address
         * (match.getNetworkSource()),IPv4
         * .fromIPv4Address(match.getNetworkDestination()));
         */
        // Reference the packet buffered at the switch by id
        po.setBufferId(pi.getBufferId());
        if (pi.getBufferId() == OFPacketOut.BUFFER_ID_NONE) {
            /**
             * The packet was NOT buffered at the switch, therefore we must copy
             * the packet's data from the OFPacketIn to our new OFPacketOut
             * message.
             */
            po.setPacketData(pi.getPacketData());
        }
        // Send the OFPacketOut to the switch

        // if faz um firewall...
        /*
         * if(IPv4.fromIPv4Address(match.getNetworkSource()).equals("10.0.0.1"))
         * { log.info("Boqueia"); log.info("\tPortIn {}:", pi.getInPort());
         * log.info("\tL2  type {}, {}->{}",match.getDataLayerType(),
         * HexString.toHexString
         * (match.getDataLayerSource()),HexString.toHexString
         * (match.getDataLayerDestination()));
         * log.info("\tL3 proto {}, {}->{}",match
         * .getNetworkProtocol(),IPv4.fromIPv4Address
         * (match.getNetworkSource()),IPv4
         * .fromIPv4Address(match.getNetworkDestination())); } else
         */
        sw.getOutputStream().write(po);
    }
    
    /**
     * 
     * @param sw Switch
     * @param pi pacote de entrada
     * @throws IOException
     * 
     * Encaminha os pacotes para o destino:
     * 1) verifica se o switch sabe a porta a ser encaminhada, caso n�o envia para todas as portas do switch tal como um hub (forwardAsHub)
     * 2) caso j� conhe�a a porta de destino ele envia como se fosse um switch, mas:
     *      2.1) Pode escolher enviar para uma fila de prioridade com largura de banda restrira
     *      2.2) Pode enviar como um switch normal - com largura de banda padr�o da porta
     *      2.3) Pode bloquear o pacote TODO implementar/melhorar a fun��o de bloquear
     * 
     */

    public void forwardAsLearningSwitchWithIPS(IOFSwitch sw, OFPacketIn pi)
            throws IOException {

        Map<Long, Short> macTable = macTables.get(sw);

        // Build the Match
        OFMatch match = OFMatch.load(pi.getPacketData(), pi.getInPort());

        // Learn the port to reach the packet's source MAC
        macTable.put(Ethernet.toLong(match.getDataLayerSource()),
                pi.getInPort());

        // Retrieve the port previously learned for the packet's dest MAC
        Short outPort = macTable.get(Ethernet.toLong(match
                .getDataLayerDestination()));

        // TODO criar um fluxo para duas portas

        if (outPort != null) { 
            int acaoDDoS = 100;
            int acaoIDS = 100;
            int acao = MensagemAlerta.PACOTE_NORMAL;
            // DDoS desabilitar para teste sem arquitetura
//            HashMap<Integer, ConexaoDDoS> cDDoS = new HashMap<Integer, ConexaoDDoS>();
//            cDDoS = analysisFlow.getcDDoS();
//            if (cDDoS.containsKey(match.getNetworkSource())) {
//                ConexaoDDoS conexao = cDDoS.get(match.getNetworkSource());
//                if (conexao.getNetworkDestination() == match.getNetworkDestination()) {
//                    acaoDDoS = conexao.getPriorityAlert();
//                    log.debug("DDoS com ip origem {} e ip destino {}, nconexao= {}",
//                    conexao.getNetworkSource(), conexao.getNetworkDestination(), conexao.getNumeroConexoesSuspeitasDDos());
//                }
//            }
            // fim DDoS
            // Para desabilitar o IDS para teste sem arquitetura n�o ligue o script que captura alertas!
            acaoIDS = ips.verificaFluxo(pi);
            if(acaoIDS<acaoDDoS) {
                acao=acaoIDS;
                log.debug("Ganhou IDS prioridade {}", acao);
            }
            else {
                acao=acaoDDoS;
                log.debug("Ganhou DDoS prioridade {}", acao);
            }
            // fim teste
            
            switch(acao) {
                case MensagemAlerta.PACOTE_NORMAL:
                    //log.debug("Pacote NORMAL encaminhado normalmente sem alerta");
                    enviaPacoteNormal(sw, pi, match, outPort);
                    //enviaPacoteQueue(sw, QUEUE_LARGURA_BANDA_ALTA, match, outPort, pi);
                    break;
                case MensagemAlerta.ALERTA_PRIORIDADE_BAIXA:
                    log.debug("!-!-!-! Alerta de prioridade baixa");
                    enviaPacoteQueue(sw, QUEUE_LARGURA_BANDA_MEDIA, match, outPort, pi);
                    break;
                case MensagemAlerta.ALERTA_PRIORIDADE_MEDIA:
                    log.debug("!+!+!+! Alerta de prioridade media");
                    enviaPacoteQueue(sw, QUEUE_LARGURA_BANDA_BAIXA, match, outPort, pi);
                    break;
                case MensagemAlerta.ALERTA_PRIORIDADE_ALTA:
                    log.debug("!*!*!*! Bloquear pacote Alerta de prioridade alta");
                    break;
                default:
                    log.debug("********ATEN��O - Pacote com prioridade DESCONHECIDA!!!!*******");
                    enviaPacoteNormal(sw, pi, match, outPort);
            }
            
        } else {
            // Destination port unknown, flood packet to all ports
            forwardAsHub(sw, pi);
        }
    }
    
    /**
     * @param msg
     * @param sw
     * @param match
     * 
     *            Deleta os fluxos apenas utilizando IPOrigem IPDetino. 
     *            � para bloquear fluxo ICMP, por exemplo, que n�o
     *            tem os campos portas.
     * 
     */
    private void deletaFluxoIPSrcIPDst(IOFSwitch sw, OFMatch match) {
 //       match.setNetworkSource(msg.getNetworkSource());
 //       match.setNetworkDestination(msg.getNetworkDestination());
 //       match.setNetworkProtocol((byte) msg.getNetworkProtocol());
        match.setWildcards(OFMatch.OFPFW_ALL
                ^ (OFMatch.OFPFW_NW_SRC_MASK | OFMatch.OFPFW_NW_DST_MASK ));

        OFMessage fm = ((OFFlowMod) sw.getInputStream()
                .getMessageFactory()

                .getMessage(OFType.FLOW_MOD))

        .setMatch(match)

        .setCommand(OFFlowMod.OFPFC_DELETE)

        .setOutPort(OFPort.OFPP_NONE)

        .setLength(U16.t(OFFlowMod.MINIMUM_LENGTH));

        try {
            sw.getOutputStream().write(fm);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            log.debug("Imposs�vel deletar fluxo");
            e.printStackTrace();
        }
    }
    
    /**
     * @param sw
     * 
     * Deletar todos os fluxos de um Switch
     * 
     */
    private void deleteAllFlowMod(IOFSwitch sw) {
        OFMatch match = new OFMatch().setWildcards(OFMatch.OFPFW_ALL);
        OFMessage fm = ((OFFlowMod) sw.getInputStream().getMessageFactory()

            .getMessage(OFType.FLOW_MOD))

            .setMatch(match)

            .setCommand(OFFlowMod.OFPFC_DELETE)

            .setOutPort(OFPort.OFPP_NONE)

            .setLength(U16.t(OFFlowMod.MINIMUM_LENGTH));

        try {
            sw.getOutputStream().write(fm);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            log.debug("Imposs�vel deletar fluxo");
            e.printStackTrace();
        }

    }

    /**
     * @param sw
     * @param pi
     * @param match
     * @param outPort
     * @throws IOException
     */
    private void enviaPacoteNormal(IOFSwitch sw, OFPacketIn pi, OFMatch match, Short outPort) throws IOException {
        // Destination port known, push down a flow
        OFFlowMod fm = new OFFlowMod();
        fm.setBufferId(pi.getBufferId());
        // Use the Flow ADD command
        fm.setCommand(OFFlowMod.OFPFC_ADD);
        // Time out the flow after 5 seconds if inactivity
        fm.setIdleTimeout((short) 5);
        // Match the packet using the match created above
        fm.setMatch(match);
        // Send matching packets to outPort
        OFAction action = new OFActionOutput(outPort);
        fm.setActions(Collections.singletonList((OFAction) action));
        // Send this OFFlowMod to the switch
        sw.getOutputStream().write(fm);

        if (pi.getBufferId() == OFPacketOut.BUFFER_ID_NONE) {
            /**
             * EXTRA CREDIT: This is a corner case, the packet was not
             * buffered at the switch so it must be sent as an
             * OFPacketOut after sending the OFFlowMod
             */
            OFPacketOut po = new OFPacketOut();
            action = new OFActionOutput(outPort);
            po.setActions(Collections.singletonList(action));
            po.setBufferId(OFPacketOut.BUFFER_ID_NONE);
            po.setInPort(pi.getInPort());
            po.setPacketData(pi.getPacketData());
            sw.getOutputStream().write(po);
        }
    }
    
 
    /**
     * @param sw - Switch que ser� envaminhado
     * @param queueNumber - N�mero da Queue/fila que ser� utilizada
     * @param match - 
     * @param outPort - porta de sa�da
     * @throws IOException
     */
    private void enviaPacoteQueue(IOFSwitch sw, int queueNumber, OFMatch match, Short outPort, OFPacketIn pi)
            throws IOException {
        List<OFAction> act = new ArrayList<OFAction>();
        short flowModLength = (short) OFFlowMod.MINIMUM_LENGTH;

        OFActionEnqueue actionEnque = new OFActionEnqueue();
        actionEnque.setPort(outPort);
        actionEnque.setQueueId(queueNumber); // n�mero da queue/fila que ser� usada
        flowModLength += OFActionEnqueue.MINIMUM_LENGTH;
        act.add(actionEnque);
        OFFlowMod fm = (OFFlowMod) sw.getInputStream()
                .getMessageFactory().getMessage(OFType.FLOW_MOD);
        fm.setBufferId(-1).setIdleTimeout((short) 100)
                .setHardTimeout((short) 100)
                .setOutPort((short) OFPort.OFPP_ALL.getValue())
                .setMatch(match).setActions(act)
                .setLength(U16.t(flowModLength));
        sw.getOutputStream().write(fm);
        
        /*
         * TODO
         * O c�digo abaixo foi adicionado para teste, esse c�digo havia no
         * c�digo original e foi adicionado e aparentemente n�o causou
         * problemas!
         * 
         * Estudar melhor o que faz esse c�digo
         */
        
        OFAction action = new OFActionOutput(outPort);
        fm.setActions(Collections.singletonList((OFAction) action));
        
        if (pi.getBufferId() == OFPacketOut.BUFFER_ID_NONE) {
            /**
             * EXTRA CREDIT: This is a corner case, the packet was not
             * buffered at the switch so it must be sent as an
             * OFPacketOut after sending the OFFlowMod
             */
            OFPacketOut po = new OFPacketOut();
            action = new OFActionOutput(outPort);
            po.setActions(Collections.singletonList(action));
            po.setBufferId(OFPacketOut.BUFFER_ID_NONE);
            po.setInPort(pi.getInPort());
            po.setPacketData(pi.getPacketData());
            sw.getOutputStream().write(po);
        }
        
        // fim do c�digo de teste
        
    }
        
    private Collection<IOFSwitch> obterSwitchesNaRede() {
        log.debug("Obter switches na rede");
        if (beaconProvider.getListeningIPAddress().isAnyLocalAddress()) {
            // TODO ERRO - a vezes aparecem sw que nao estao na lista! acho que
            // as linhas abaixo corrigiram o problema
            Collection<IOFSwitch> col = new HashSet<IOFSwitch>();
            col.clear();
            col = beaconProvider.getSwitches().values();
            return col;
        } else {
            log.debug("Aten��o - N�o existem Switches dispon�veis na rede");
        }
        return null;
    }
    
    
    public void apagarTodosFluxosTodosSwitches() {
        log.debug("Apagar todos Fluxos de Todos os Switches");
        Collection<IOFSwitch> switches = new HashSet<IOFSwitch>();
        switches = obterSwitchesNaRede();
        for(IOFSwitch s : switches) {
            IOFSwitch sw = beaconProvider.getSwitches().get(s.getId());
            deleteAllFlowMod(sw);
        }
    }



    // ---------- NO NEED TO EDIT ANYTHING BELOW THIS LINE ----------

    /**
     * Ensure there is a MAC to port table per switch
     * 
     * @param sw
     */
    private void initMACTable(IOFSwitch sw) {
        Map<Long, Short> macTable = macTables.get(sw);
        if (macTable == null) {
            macTable = new HashMap<Long, Short>();
            macTables.put(sw, macTable);
        }
    }

    @Override
    public void addedSwitch(IOFSwitch sw) {
        
        

    }

    @Override
    public void removedSwitch(IOFSwitch sw) {
        macTables.remove(sw);
    }

    /**
     * @param beaconProvider
     *            the beaconProvider to set
     */
    public void setBeaconProvider(IBeaconProvider beaconProvider) {
        this.beaconProvider = beaconProvider;
    }

    public void startUp() {
        log.trace("=======================Starting");
        // beaconProvider.addOFMessageListener(OFType.PACKET_IN, this);
        beaconProvider.addOFMessageListener(OFType.PACKET_IN, this);
        beaconProvider.addOFMessageListener(OFType.STATS_REPLY, this);
        beaconProvider.addOFSwitchListener(this);
 

        // EnviaStatusRequest enviaStatusRequest = new EnviaStatusRequest();
        // enviaStatusRequest.startUp(beaconProvider);
        
        // Thread para analisar 

        analysisFlow.startUp(beaconProvider);
        analysisFlow.start();
        
        // Thread para obter os alertas de seguran�a!
        ips.startUp(beaconProvider);
        ips.start();
        //intrusionPreventionSystem.start();

    }

    public void shutDown() {
        log.trace("Stopping");
        beaconProvider.removeOFMessageListener(OFType.PACKET_IN, this);
        beaconProvider.removeOFMessageListener(OFType.STATS_REPLY, this);
        beaconProvider.removeOFSwitchListener(this);
    }

    public String getName() {
        return "tutorial";
    }

    // teste

    // final teste

}
